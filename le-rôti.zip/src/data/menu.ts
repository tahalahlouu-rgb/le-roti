import { MenuItem, MenuCategory } from "../types";

export const categories: MenuCategory[] = [
  {
    id: "rotisserie",
    name: "Poulets Rôtis",
    icon: "Flame",
    description: "Le cœur de notre savoir-faire : nos poulets rôtis à la perfection, juteux à l'intérieur et croustillants à l'extérieur.",
    image: "/src/assets/images/hero_rotisserie_1783705241916.jpg"
  },
  {
    id: "plats-modernes",
    name: "Plats Modernes",
    icon: "UtensilsCrossed",
    description: "Des recettes revisitées, gourmandes et contemporaines, pour tous les goûts.",
    image: "/src/assets/images/gourmet_platter_1783705262344.jpg"
  },
  {
    id: "marocain",
    name: "Plats Marocains",
    icon: "Sparkles",
    description: "Le meilleur de la tradition marocaine fait maison, servi certains jours spécifiques.",
    image: "/src/assets/images/moroccan_rfissa_1783705276130.jpg"
  },
  {
    id: "sandwichs",
    name: "Sandwichs & Clubs",
    icon: "Sandwich",
    description: "De savoureux sandwichs garnis de nos viandes marinées et ingrédients de premier choix.",
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "pates",
    name: "Farfalles",
    icon: "Soup",
    description: "Nos recettes de pâtes gourmandes et onctueuses.",
    image: "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "salades-soupes",
    name: "Salades & Soupes",
    icon: "Salad",
    description: "De la fraîcheur et du réconfort avec nos salades croquantes et nos soupes traditionnelles.",
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "accompagnements",
    name: "Accompagnements",
    icon: "Cookie",
    description: "Portions individuelles préparées maison pour parfaire vos grillades.",
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus",
    name: "Jus Naturels",
    icon: "CupSoda",
    description: "Jus de fruits frais pressés minute pour un maximum de vitamines.",
    image: "https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "desserts",
    name: "Desserts",
    icon: "Cake",
    description: "Pour finir sur une note sucrée et raffinée.",
    image: "https://images.unsplash.com/photo-1524351199679-46cddf530c04?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "boissons",
    name: "Boissons",
    icon: "Beer",
    description: "Eaux, sodas et boissons fraîches gazeuses.",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=600"
  }
];

export const menuItems: MenuItem[] = [
  // Plats Poulets Rôtis
  {
    id: "rot-1",
    name: "1/4 Poulet Rôti",
    price: 50.40,
    description: "Servi avec sauce tomate, riz parfumé, frites maison croustillantes ou légumes de saison sautés.",
    category: "rotisserie",
    image: "/src/assets/images/gourmet_platter_1783705262344.jpg"
  },
  {
    id: "rot-2",
    name: "1/2 Poulet Rôti",
    price: 90.00,
    description: "Servi avec sauce tomate, riz parfumé, frites maison croustillantes ou légumes de saison sautés. Idéal pour les grosses faims.",
    category: "rotisserie",
    image: "/src/assets/images/gourmet_platter_1783705262344.jpg"
  },
  {
    id: "rot-3",
    name: "1 Poulet Rôti Entier",
    price: 179.00,
    description: "Le classique incontournable : un poulet entier doré à la perfection, servi avec sauce tomate, riz parfumé, frites maison ou légumes de saison.",
    category: "rotisserie",
    image: "/src/assets/images/hero_rotisserie_1783705241916.jpg"
  },
  {
    id: "rot-4",
    name: "1 Poulet Rôti Entier Seul",
    price: 129.00,
    description: "Notre délicieux poulet rôti entier seul, idéal à partager à la maison en famille.",
    category: "rotisserie",
    image: "/src/assets/images/hero_rotisserie_1783705241916.jpg"
  },

  // Plats Modernes
  {
    id: "mod-1",
    name: "Plat Émincé De Poulet Sauce Curry",
    price: 79.00,
    description: "Émincé de poulet tendre nappé d'une sauce curry douce et parfumée, servi avec son riz doré et petits légumes.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1631291439872-efa9c8fdeecf?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mod-2",
    name: "Plat Gratin de Poulet",
    price: 75.00,
    description: "Un gratin de poulet ultra généreux, crémeux et perfectly doré au fromage fondu.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1642683215891-1341ed240578?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mod-3",
    name: "Plat Brochette De Poulet",
    price: 75.00,
    description: "Brochettes de poulet tendres marinées, grillées à la perfection et pleines de saveurs fumées.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mod-4",
    name: "Plat Cordon Bleu",
    price: 74.00,
    description: "Cordon bleu maison croustillant au fromage coulant et blanc de poulet tendre, servi avec purée ou frites.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1598103442097-8b74394b98c6?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mod-5",
    name: "Hachis Parmentier De Poulet",
    price: 66.00,
    description: "Haché parmentier de poulet mijoté aux petits oignons, fondant et réconfortant sous sa couche de purée gratinée.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mod-6",
    name: "Omelette aux herbes",
    price: 30.00,
    description: "Omelette baveuse préparée aux herbes fraîches du marché, servie avec du pain croustillant.",
    category: "plats-modernes",
    image: "https://images.unsplash.com/photo-1594756297462-028bb8e8a043?auto=format&fit=crop&q=80&w=600"
  },

  // Plats Marocains
  {
    id: "mar-1",
    name: "Seffa Mdfouna",
    price: 69.00,
    description: "Chaque Lundi — Vermicelles de Seffa fondants cuits à la vapeur, parfumés à la cannelle, sucre glace, amandes frites concassées, abritant un délicieux poulet effiloché savoureusement épicé.",
    category: "marocain",
    image: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "mar-2",
    name: "Rfissa au Poulet",
    price: 69.00,
    description: "Chaque Mercredi — Plat traditionnel marocain réconfortant à base de feuilleté de msemmen émincé, mijoté dans une sauce onctueuse aux lentilles, oignons confits, fénugrec, et poulet fermier parfumé.",
    category: "marocain",
    image: "/src/assets/images/moroccan_rfissa_1783705276130.jpg"
  },
  {
    id: "mar-3",
    name: "Couscous Sept Légumineuses",
    price: 69.00,
    description: "Chaque Vendredi — Le couscous traditionnel aux sept légumes frais mijotés lentement, semoule fine et aérée, servi avec son bol de Lben (lait fermenté frais) traditionnel.",
    category: "marocain",
    image: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600"
  },

  // Sandwichs
  {
    id: "snd-1",
    name: "Sandwich Poulet Curry",
    price: 60.00,
    description: "Poulet émincé relevé d'une sauce curry douce et parfumée, salade, tomates, servi dans un pain croustillant.",
    category: "sandwichs",
    image: "https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "snd-2",
    name: "Club Sandwich Complet",
    price: 60.00,
    description: "Une version gourmande et nutritive avec un pain de mie complet aux graines, poulet émincé, œuf dur, salade, tomate et sauce maison.",
    category: "sandwichs",
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "snd-3",
    name: "Sandwich Poulet Mayonnaise",
    price: 58.00,
    description: "Tendres morceaux de poulet émincé finement, mayonnaise onctueuse maison et crudités croquantes.",
    category: "sandwichs",
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "snd-4",
    name: "Club Sandwich Blanc",
    price: 58.00,
    description: "Le club sandwich classique au pain de mie blanc toasté, filet de poulet, œuf, salade croquante, tranches de tomate.",
    category: "sandwichs",
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=600"
  },

  // Pâtes
  {
    id: "pat-1",
    name: "Farfalle au Poulet",
    price: 79.00,
    description: "Pâtes Farfalle cuisinées avec une sauce béchamel onctueuse, émincé de poulet, champignons frais, parmesan râpé et poireaux fondants.",
    category: "pates",
    image: "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "pat-2",
    name: "Farfalle Végétarienne",
    price: 69.00,
    description: "Pâtes Farfalle fraîches sautées aux carottes tendres, courgettes croquantes, poivrons colorés, brocolis, nappées d'une savoureuse sauce pesto.",
    category: "pates",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&q=80&w=600"
  },

  // Salades et Soupes
  {
    id: "sal-1",
    name: "Salade César",
    price: 69.00,
    description: "Cœur de laitue romaine croquante, croûtons dorés à l'ail, blanc de poulet grillé émincé, tomates cerises juteuses, copeaux de Parmesan et notre sauce César maison.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "sal-2",
    name: "Chef de salade",
    price: 69.00,
    description: "Mélange frais de laitue, tomates, haricots verts, pommes de terre fondantes, poivrons colorés, œuf dur, et miettes de thon premium.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "sal-3",
    name: "Salade Le Rotî",
    price: 55.00,
    description: "Notre salade signature : laitue romaine, tomates fraîches, carottes râpées, concombres croquants, pommes de terre, riz gourmand et assaisonnement secret du chef.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "sal-4",
    name: "Salade Marocaine",
    price: 49.00,
    description: "Dés frais de tomates mûres, concombres et oignons doux, poivrons verts grillés, olives noires parfumées et vinaigrette au cumin.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "sal-5",
    name: "Velouté de Légumes",
    price: 40.00,
    description: "Velouté onctueux de légumes frais de saison, accompagné de croûtons croustillants dorés et de fromage fondant.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "sal-6",
    name: "Soupe Harira Traditionnelle",
    price: 30.00,
    description: "L'incontournable soupe marocaine riche en herbes et épices, servie chaude avec dattes mûres, Chebakia parfumée, pain frais et quartier de citron.",
    category: "salades-soupes",
    image: "https://images.unsplash.com/photo-1547592165-e1d17fed6005?auto=format&fit=crop&q=80&w=600"
  },

  // Accompagnements
  {
    id: "acc-1",
    name: "Portion de Légumes de Saison",
    price: 21.00,
    description: "Un délicieux mélange de légumes de saison, sautés minute, croquants et savoureux.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-2",
    name: "Portion Pomme de Terre",
    price: 21.00,
    description: "Pommes de terre fondantes aux herbes, dorées lentement au four with un filet d'huile d'olive de qualité.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-3",
    name: "Portion Purée de Pomme de Terre",
    price: 21.00,
    description: "Une purée de pommes de terre maison onctueuse, crémeuse, montée au beurre et délicatement assaisonnée.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-4",
    name: "Portion d'Aubergines Confites",
    price: 21.00,
    description: "Aubergines fondantes cuites lentement aux herbes aromatiques et doucement confites à l'huile d'olive.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1601356616077-695728ecf769?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-5",
    name: "Portion Riz Parfumé",
    price: 21.00,
    description: "Riz blanc de qualité supérieure parfaitement cuit, léger, aéré et délicatement parfumé aux épices douces.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-6",
    name: "Portion de Courgettes",
    price: 21.00,
    description: "Fines rondelles de courgettes sautées à l'huile d'olive, légères, parfumées et pleines de fraîcheur.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1601356616077-695728ecf769?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-7",
    name: "Portion Haricots Verts Sautés",
    price: 21.00,
    description: "Haricots verts extra-fins sautés à l'ail rôti et persil frais ciselé.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1567168544646-208fa5d408fb?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-8",
    name: "Portion Frites Maison",
    price: 20.00,
    description: "Frites fraîches faites maison, croustillantes et dorées à souhait, préparées avec amour.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-9",
    name: "Portion de Vermicelles",
    price: 19.00,
    description: "Vermicelles légères et délicatement parfumées au safran et cannelle, l'accompagnement idéal.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "acc-10",
    name: "Portion Carotte Glacée",
    price: 19.00,
    description: "Carottes tendres cuites doucement et légèrement glacées pour une délicieuse touche de douceur sucrée.",
    category: "accompagnements",
    image: "https://images.unsplash.com/photo-1595855759920-86582396756a?auto=format&fit=crop&q=80&w=600"
  },

  // Jus Naturels
  {
    id: "jus-1",
    name: "Jus d'Orange Frais",
    price: 22.50,
    description: "Oranges mûres sélectionnées, pressées à la minute pour un maximum de fraîcheur.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-2",
    name: "Jus de Fraise",
    price: 30.00,
    description: "Fraises fraîches mixées sur une délicieuse base de jus d'orange frais.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-3",
    name: "Jus de Kiwi",
    price: 30.00,
    description: "Kiwi frais mixé, servi sur une base d'orange énergisante.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1589733901241-5e5148685df5?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-4",
    name: "Cocktail du Chef",
    price: 30.00,
    description: "Cocktail tonique et fruité de fruits frais mélangés, base orange pressée.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1497534446932-c925b458314e?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-5",
    name: "Jus d'Avocat",
    price: 30.00,
    description: "Avocat onctueux et crémeux, mixé avec une base de jus d'orange frais ou lait selon convenance.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1546173159-3198075829f2?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-6",
    name: "Jus Carotte Orange",
    price: 28.00,
    description: "Duo détox de carottes douces et d'oranges pressées à la minute.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-7",
    name: "Jus de Banane",
    price: 28.00,
    description: "Bananes douces mixées sur une base d'orange fraîche pour faire le plein d'énergie.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-8",
    name: "Jus Orange Carotte Banane",
    price: 27.00,
    description: "Un délicieux mélange revitalisant d'oranges fraîches, de carottes et de banane douce.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-9",
    name: "Jus de Citron Pur",
    price: 25.00,
    description: "Citrons jaunes pressés minute, frais et désaltérant.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-10",
    name: "Jus de Citron Menthe",
    price: 25.00,
    description: "Citronnade ultra-fraîche maison, agrémentée de feuilles de menthe fraîches broyées.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "jus-11",
    name: "Jus de Citron Gingembre",
    price: 21.00,
    description: "Une combinaison tonique de gingembre frais râpé et de jus de citron pressé.",
    category: "jus",
    image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=600"
  },

  // Desserts
  {
    id: "des-1",
    name: "Tiramisu Maison",
    price: 31.50,
    description: "L'indémodable tiramisu ultra-crémeux au café, génoise fondante et cacao amer saupoudré.",
    category: "desserts",
    image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "des-2",
    name: "Gâteau au fromage citronné",
    price: 39.00,
    description: "Un cheesecake incroyablement fondant sur un biscuit croustillant, sublimé par un coulis de citron acidulé.",
    category: "desserts",
    image: "https://images.unsplash.com/photo-1524351199679-46cddf530c04?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "des-3",
    name: "Salade de fruits frais",
    price: 35.00,
    description: "Un assortiment rafraîchissant de fruits frais de saison coupés finement.",
    category: "desserts",
    image: "https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "des-4",
    name: "Corbeille de fruits de saison",
    price: 35.00,
    description: "Sélection rigoureuse de fruits de saison entiers, soigneusement lavés et présentés pour la dégustation.",
    category: "desserts",
    image: "https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "des-5",
    name: "Crème caramel aux Amandes",
    price: 30.00,
    description: "Crème caramel onctueuse, nappe dorée et croquant d'amandes effilées torréfiées.",
    category: "desserts",
    image: "https://images.unsplash.com/photo-1528975604071-b4daaf306793?auto=format&fit=crop&q=80&w=600"
  },

  // Boissons
  {
    id: "bev-1",
    name: "Oulmes Gazeuse 50cl",
    price: 18.00,
    description: "Eau minérale naturellement gazeuse.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1548865143-d4840e367edd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-2",
    name: "Sidi Ali 50cl",
    price: 18.00,
    description: "Eau minérale naturelle plate.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1616118132296-ac8073741336?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-3",
    name: "Bouteille de Coca-Cola 45cl",
    price: 18.00,
    description: "Boisson gazeuse rafraîchissante.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-4",
    name: "Bouteille de Coca-Cola Zero 45cl",
    price: 18.00,
    description: "Boisson gazeuse sans sucres et sans calories.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-5",
    name: "Bouteille de Poms 45cl",
    price: 18.00,
    description: "Boisson gazeuse rafraîchissante saveur pomme.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-6",
    name: "Bouteille de Sprite 45cl",
    price: 18.00,
    description: "Boisson gazeuse limpide saveur citron et lime.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1625772291426-f15cd4526a16?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-7",
    name: "Bouteille de Schweppes Citron 45cl",
    price: 18.00,
    description: "Boisson gazeuse rafraîchissante aux arômes de citron.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-8",
    name: "Bouteille de Schweppes Tonic 45cl",
    price: 18.00,
    description: "Boisson gazeuse tonique.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1626150990416-a51c70e28ef9?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-9",
    name: "Bouteille de Hawaii Tropical 45cl",
    price: 18.00,
    description: "Boisson gazeuse saveur fruits tropicaux, favorite au Maroc.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-10",
    name: "Bouteille de Hawaii Ananas 45cl",
    price: 18.00,
    description: "Boisson gazeuse saveur douce d'ananas.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "bev-11",
    name: "Bouteille d'Orangina 50cl",
    price: 18.00,
    description: "Boisson gazeuse à la pulpe d'orange.",
    category: "boissons",
    image: "https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&q=80&w=600"
  }
];
