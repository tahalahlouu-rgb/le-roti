export const restaurantConfig = {
  name: "Le Rotî",
  slogan: "Bien plus que du poulet",
  location: "Ryad Square, food court, Rabat",
  phone: "À confirmer",
  instagram: "https://www.instagram.com/leroti_ma/?hl=fr",
  menuUrl: "https://glovo.go.link/open?link_type=store&store_id=485168&adjust_t=s321jkn",
  orderUrl: "https://glovo.go.link/open?link_type=store&store_id=485168&adjust_t=s321jkn",
  mapsUrl: "https://maps.app.goo.gl/xWAu7eT9VxtexsiX6",
  hours: {
    weekdays: "11:30 - 23:30",
    weekends: "11:30 - 00:30",
    note: "Ouvert 7j/7 au Food Court de Ryad Square"
  },
  images: {
    hero: "/src/assets/images/hero_rotisserie_1783705241916.jpg",
    gourmetPlatter: "/src/assets/images/gourmet_platter_1783705262344.jpg",
    traditional: "/src/assets/images/moroccan_rfissa_1783705276130.jpg"
  }
};
