import React, { useEffect, useState, useMemo } from "react";
import { motion } from "motion/react";

interface IntroScreenProps {
  onEnter: () => void;
}

export default function IntroScreen({ onEnter }: IntroScreenProps) {
  const [reducedMotion, setReducedMotion] = useState(false);

  // Detect prefers-reduced-motion
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mediaQuery.matches);
    const listener = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener("change", listener);
    return () => mediaQuery.removeEventListener("change", listener);
  }, []);

  // Prevent background scrolling while intro is visible
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  // Stable generate embers only once on mount
  const embers = useMemo(() => {
    const count = 15;
    return Array.from({ length: count }).map((_, i) => ({
      id: i,
      left: `${5 + Math.random() * 90}%`,
      bottom: `${-5 - Math.random() * 15}%`,
      size: Math.random() * 4 + 2, // 2px to 6px
      duration: Math.random() * 4 + 4, // 4s to 8s
      delay: Math.random() * 2, // staggered delays
      drift: (Math.random() - 0.5) * 80, // -40px to +40px horizontal drift
    }));
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-brand-black overflow-hidden flex flex-col items-center justify-center p-6 select-none">
      
      {/* 1. Skip / Passer button (top right) */}
      <motion.button
        onClick={onEnter}
        className="absolute top-6 right-6 px-4 py-2 font-sans text-xs tracking-widest uppercase text-brand-ivoire/40 hover:text-brand-gold hover:border-brand-gold/30 border border-transparent rounded-lg transition-all duration-300 cursor-pointer z-20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
      >
        Passer
      </motion.button>

      {/* 2. Subtly moving golden radial glow behind the logo */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] sm:w-[500px] h-[320px] sm:h-[500px] rounded-full pointer-events-none -z-10"
        style={{
          background: "radial-gradient(circle, rgba(183, 154, 85, 0.16) 0%, rgba(183, 154, 85, 0.04) 45%, transparent 75%)"
        }}
        animate={
          reducedMotion
            ? {}
            : {
                scale: [0.95, 1.05, 0.95],
                opacity: [0.8, 1, 0.8],
              }
        }
        transition={
          reducedMotion
            ? {}
            : {
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut",
              }
        }
      />

      {/* 3. Discrete rising ember particles */}
      {!reducedMotion && (
        <div className="absolute inset-0 pointer-events-none z-0">
          {embers.map((ember) => (
            <motion.div
              key={ember.id}
              className="absolute bg-brand-braise rounded-full opacity-60"
              style={{
                left: ember.left,
                bottom: ember.bottom,
                width: ember.size,
                height: ember.size,
                boxShadow: "0 0 6px #C86428, 0 0 10px #B79A55",
              }}
              animate={{
                y: "-115vh",
                x: ember.drift,
                opacity: [0, 0.8, 0.4, 0],
              }}
              transition={{
                duration: ember.duration,
                repeat: Infinity,
                delay: ember.delay,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>
      )}

      {/* 4. Center Visual Stack */}
      <div className="relative z-10 flex flex-col items-center max-w-lg w-full text-center">
        
        {/* Real Logo Title with refined typography */}
        <motion.h1
          className="font-serif text-5xl sm:text-7xl font-bold tracking-[0.18em] uppercase text-brand-gold select-none leading-none"
          initial={{ opacity: 0, y: -25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          Le Rotî
        </motion.h1>

        {/* Real Slogan */}
        <motion.p
          className="text-brand-gold-light font-serif text-sm sm:text-base italic tracking-[0.2em] mt-4 opacity-90 select-none leading-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
        >
          « Bien plus que du poulet »
        </motion.p>

        {/* Elegant Thin Decorative Divider */}
        <motion.div
          className="w-16 h-[1.5px] bg-brand-gold/30 my-6"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
        />

        {/* Main Entry Button */}
        <motion.button
          onClick={onEnter}
          className="gold-button px-8 py-3.5 rounded-full font-sans font-bold text-xs uppercase tracking-[0.15em] cursor-pointer shadow-[0_4px_15px_rgba(183,154,85,0.2)] flex items-center justify-center gap-2 transform active:scale-95"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6, ease: "easeOut" }}
          whileHover={{
            scale: reducedMotion ? 1 : 1.05,
            transition: { duration: 0.2 }
          }}
        >
          <span>Entrer chez Le Rotî</span>
        </motion.button>

      </div>
      
    </div>
  );
}
