import React, { useState, useEffect } from "react";
import Logo from "./Logo";
import { restaurantConfig } from "../data/restaurant";
import { Menu, X, ShoppingBag, MapPin, Instagram } from "lucide-react";

interface NavbarProps {
  currentRoute: string;
  onNavigate: (route: string) => void;
}

export default function Navbar({ currentRoute, onNavigate }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { label: "Accueil", path: "/" },
    { label: "Notre Carte", path: "/menu" },
    { label: "Nous Trouver & Contact", path: "/contact" },
  ];

  const handleNavClick = (path: string) => {
    onNavigate(path);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        scrolled
          ? "bg-brand-black/95 backdrop-blur-md border-b border-brand-ivoire/10 py-4 shadow-xl"
          : "bg-gradient-to-b from-brand-black/80 to-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="flex items-center justify-between">
          {/* Logo Section */}
          <div
            className="cursor-pointer transition-transform duration-300 hover:scale-102"
            onClick={() => handleNavClick("/")}
          >
            <Logo variant="gold" showSlogan={true} />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-10">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavClick(item.path)}
                className={`font-sans text-[11px] uppercase tracking-[0.2em] font-bold transition-all duration-300 relative py-1 cursor-pointer ${
                  currentRoute === item.path
                    ? "text-brand-gold"
                    : "text-brand-ivoire hover:text-brand-gold-light"
                }`}
              >
                {item.label}
                {currentRoute === item.path && (
                  <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-brand-gold rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Actions (Desktop) */}
          <div className="hidden md:flex items-center space-x-6">
            <a
              href={restaurantConfig.instagram}
              target="_blank"
              rel="noreferrer"
              className="text-brand-ivoire hover:text-brand-gold transition-colors p-2"
              title="Nous suivre sur Instagram"
            >
              <Instagram size={18} />
            </a>
            <a
              href={restaurantConfig.mapsUrl}
              target="_blank"
              rel="noreferrer"
              className="text-brand-ivoire hover:text-brand-gold transition-colors p-2"
              title="Nous situer sur Google Maps"
            >
              <MapPin size={18} />
            </a>
            <a
              href={restaurantConfig.orderUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-2 px-6 py-2.5 rounded-full text-brand-black bg-brand-gold hover:bg-brand-gold-light font-sans text-[11px] uppercase tracking-widest font-extrabold shadow-lg transition-all duration-300 transform hover:-translate-y-0.5"
            >
              <ShoppingBag size={14} />
              <span>Commander</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            <a
              href={restaurantConfig.orderUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-full text-brand-black bg-brand-gold font-sans text-[10px] uppercase tracking-wider font-extrabold transition-all"
            >
              <ShoppingBag size={12} />
              <span>Glovo</span>
            </a>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-brand-ivoire hover:text-brand-gold transition-colors p-1 cursor-pointer"
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {isOpen && (
        <div className="md:hidden bg-brand-charcoal border-b border-brand-ivoire/10 px-6 py-8 space-y-6 shadow-2xl animate-fade-in">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavClick(item.path)}
                className={`text-left font-sans text-xs uppercase tracking-widest font-bold py-2 transition-colors cursor-pointer ${
                  currentRoute === item.path ? "text-brand-gold font-extrabold" : "text-brand-ivoire hover:text-brand-gold-light"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-6 border-t border-brand-ivoire/10 flex items-center justify-between">
            <div className="flex space-x-4">
              <a
                href={restaurantConfig.instagram}
                target="_blank"
                rel="noreferrer"
                className="text-brand-ivoire hover:text-brand-gold p-2"
              >
                <Instagram size={20} />
              </a>
              <a
                href={restaurantConfig.mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="text-brand-ivoire hover:text-brand-gold p-2"
              >
                <MapPin size={20} />
              </a>
            </div>
            <a
              href={restaurantConfig.orderUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-full text-brand-black bg-brand-gold font-sans text-[10px] uppercase tracking-widest font-extrabold"
            >
              <ShoppingBag size={14} />
              <span>Commander sur Glovo</span>
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
