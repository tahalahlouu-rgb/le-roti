import React from "react";

interface LogoProps {
  variant?: "gold" | "ivory-badge" | "plain-white";
  className?: string;
  showSlogan?: boolean;
}

export default function Logo({
  variant = "gold",
  className = "",
  showSlogan = true,
}: LogoProps) {
  if (variant === "ivory-badge") {
    return (
      <div className={`inline-flex flex-col items-center justify-center bg-brand-ivoire p-4 rounded-md shadow-lg border border-brand-gold/20 ${className}`}>
        <span className="font-serif text-3xl font-bold tracking-[0.15em] uppercase text-brand-charcoal select-none leading-none">
          Le Rotî
        </span>
        {showSlogan && (
          <span className="font-serif text-[10px] uppercase tracking-[0.2em] text-brand-olive mt-1.5 select-none leading-none">
            Bien plus que du poulet
          </span>
        )}
      </div>
    );
  }

  const textColor = variant === "plain-white" ? "text-white" : "text-brand-gold";
  const sloganColor = variant === "plain-white" ? "text-gray-300" : "text-brand-gold-light";

  return (
    <div className={`flex flex-col ${className}`}>
      <span className={`font-serif text-2xl sm:text-3xl font-bold tracking-[0.15em] uppercase ${textColor} select-none leading-none`}>
        Le Rotî
      </span>
      {showSlogan && (
        <span className={`text-[10px] uppercase tracking-[0.2em] ${sloganColor} opacity-80 mt-1.5 select-none leading-none font-sans`}>
          Bien plus que du poulet
        </span>
      )}
    </div>
  );
}
