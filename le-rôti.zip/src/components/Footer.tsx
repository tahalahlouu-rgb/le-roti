import React from "react";
import Logo from "./Logo";
import { restaurantConfig } from "../data/restaurant";
import { Instagram, MapPin, Phone, Clock, ArrowRight, Shield } from "lucide-react";

interface FooterProps {
  onNavigate: (route: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-charcoal border-t border-brand-gold/15 pt-16 pb-8 text-brand-ivoire">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-8 mb-12">
          {/* Brand Info */}
          <div className="md:col-span-1 flex flex-col space-y-4">
            <Logo variant="gold" showSlogan={true} className="mb-2" />
            <p className="text-sm text-gray-400 font-sans leading-relaxed">
              Une expérience de rôtisserie unique au cœur de Rabat. Retrouvez des plats savoureux préparés minute et des spécialités traditionnelles à partager.
            </p>
            <div className="flex space-x-3 pt-2">
              <a
                href={restaurantConfig.instagram}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full border border-brand-gold/20 flex items-center justify-center hover:bg-brand-gold hover:text-brand-black transition-all duration-300"
                title="Suivez-nous"
              >
                <Instagram size={18} />
              </a>
              <a
                href={restaurantConfig.mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full border border-brand-gold/20 flex items-center justify-center hover:bg-brand-gold hover:text-brand-black transition-all duration-300"
                title="Google Maps"
              >
                <MapPin size={18} />
              </a>
            </div>
          </div>

          {/* Opening Hours */}
          <div className="flex flex-col space-y-4">
            <h3 className="font-serif text-sm font-bold text-brand-gold tracking-[0.2em] uppercase">
              Horaires d'Ouverture
            </h3>
            <ul className="space-y-3 font-sans text-sm text-gray-300">
              <li className="flex items-start space-x-2">
                <Clock size={16} className="text-brand-gold-light mt-0.5 shrink-0" />
                <div>
                  <span className="block font-medium">Lundi à Vendredi</span>
                  <span className="text-xs text-gray-400">{restaurantConfig.hours.weekdays}</span>
                </div>
              </li>
              <li className="flex items-start space-x-2">
                <Clock size={16} className="text-brand-gold-light mt-0.5 shrink-0" />
                <div>
                  <span className="block font-medium">Samedi et Dimanche</span>
                  <span className="text-xs text-gray-400">{restaurantConfig.hours.weekends}</span>
                </div>
              </li>
              <li className="text-xs text-brand-gold-light italic">
                * {restaurantConfig.hours.note}
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col space-y-4">
            <h3 className="font-serif text-sm font-bold text-brand-gold tracking-[0.2em] uppercase">
              Navigation
            </h3>
            <ul className="space-y-2.5 font-sans text-sm">
              <li>
                <button
                  onClick={() => onNavigate("/")}
                  className="hover:text-brand-gold transition-colors flex items-center space-x-1.5 text-gray-300 cursor-pointer"
                >
                  <ArrowRight size={12} className="text-brand-gold" />
                  <span>Accueil</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("/menu")}
                  className="hover:text-brand-gold transition-colors flex items-center space-x-1.5 text-gray-300 cursor-pointer"
                >
                  <ArrowRight size={12} className="text-brand-gold" />
                  <span>Notre Carte</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("/contact")}
                  className="hover:text-brand-gold transition-colors flex items-center space-x-1.5 text-gray-300 cursor-pointer"
                >
                  <ArrowRight size={12} className="text-brand-gold" />
                  <span>Nous Trouver & Contact</span>
                </button>
              </li>
              <li>
                <a
                  href={restaurantConfig.orderUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-brand-gold transition-colors flex items-center space-x-1.5 text-gray-300"
                >
                  <ArrowRight size={12} className="text-brand-gold" />
                  <span>Commander sur Glovo</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Location Notice */}
          <div className="flex flex-col space-y-4">
            <h3 className="font-serif text-sm font-bold text-brand-gold tracking-[0.2em] uppercase">
              Où nous trouver ?
            </h3>
            <p className="text-sm text-gray-300 font-sans leading-relaxed flex items-start space-x-2">
              <MapPin size={16} className="text-brand-gold mt-0.5 shrink-0" />
              <span>{restaurantConfig.location}</span>
            </p>
            <p className="text-sm text-gray-300 font-sans flex items-center space-x-2">
              <Phone size={16} className="text-brand-gold shrink-0" />
              <span>Tél : {restaurantConfig.phone}</span>
            </p>
            <div className="p-3.5 bg-brand-black/40 rounded-lg border border-brand-gold/10 text-xs text-gray-400 font-sans leading-relaxed">
              <span className="font-semibold text-brand-gold block mb-1">
                Note Importante :
              </span>
              Le Rotî est installé dans le food court de Ryad Square. Service direct au comptoir, pas de réservations nécessaires !
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-8 border-t border-brand-gold/10 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 font-sans space-y-4 md:space-y-0">
          <p>© {currentYear} Le Rotî Rabat. Tous droits réservés.</p>
          <div className="flex space-x-6">
            <span className="flex items-center space-x-1">
              <Shield size={12} className="text-brand-gold" />
              <span>Poulet 100% Halal certifié</span>
            </span>
            <a
              href={restaurantConfig.menuUrl}
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-gold transition-colors"
            >
              Menu Officiel Glovo
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
