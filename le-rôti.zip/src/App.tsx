import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Menu from "./pages/Menu";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import IntroScreen from "./components/IntroScreen";
import { AnimatePresence, motion } from "motion/react";

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<string>("/");
  const [showIntro, setShowIntro] = useState<boolean>(false);

  useEffect(() => {
    // Check if the user has already seen the introduction in this session
    const introSeen = sessionStorage.getItem("le_roti_intro_seen");
    if (!introSeen) {
      setShowIntro(true);
    }
  }, []);

  const handleEnter = () => {
    sessionStorage.setItem("le_roti_intro_seen", "true");
    setShowIntro(false);
  };

  // Helper to parse route path from window.location.hash
  const getPathFromHash = () => {
    const hash = window.location.hash; // e.g. "#/menu" or "#/contact" or ""
    if (!hash || hash === "#" || hash === "#/") {
      return "/";
    }
    // Remove the leading '#'
    return hash.substring(1); 
  };

  // Sync state with hash changes
  useEffect(() => {
    const handleHashChange = () => {
      const path = getPathFromHash();
      setCurrentRoute(path);
      // Smooth scroll to top on routing changes
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };

    // Initial check
    handleHashChange();

    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Update hash dynamically when user triggers state-based navigation
  const handleNavigate = (path: string) => {
    window.location.hash = `#${path}`;
  };

  // Render the appropriate page component
  const renderPage = () => {
    switch (currentRoute) {
      case "/":
        return <Home onNavigate={handleNavigate} />;
      case "/menu":
        return <Menu />;
      case "/contact":
        return <Contact />;
      default:
        return <NotFound onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="bg-brand-black min-h-screen text-brand-ivoire flex flex-col justify-between selection:bg-brand-gold selection:text-brand-black">
      <AnimatePresence mode="wait">
        {showIntro && (
          <motion.div
            key="intro-screen"
            initial={{ opacity: 1 }}
            exit={{ 
              opacity: 0,
              y: -50,
              transition: { duration: 0.8, ease: "easeInOut" } 
            }}
            className="fixed inset-0 z-50"
          >
            <IntroScreen onEnter={handleEnter} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation header */}
      <Navbar currentRoute={currentRoute} onNavigate={handleNavigate} />
      
      {/* Main Page Body */}
      <main className="flex-grow">
        {renderPage()}
      </main>

      {/* Footer information and quick-links */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
