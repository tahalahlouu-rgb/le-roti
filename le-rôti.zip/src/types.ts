export interface MenuItem {
  id: string;
  name: string;
  price: number; // in MAD
  description: string;
  category: string;
  image?: string;
  highlighted?: boolean;
}

export interface MenuCategory {
  id: string;
  name: string;
  icon: string; // Lucide icon name
  description?: string;
  image?: string;
}
