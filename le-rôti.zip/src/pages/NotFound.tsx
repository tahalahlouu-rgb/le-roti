import React from "react";
import { Flame, ArrowLeft, Home } from "lucide-react";

interface NotFoundProps {
  onNavigate: (route: string) => void;
}

export default function NotFound({ onNavigate }: NotFoundProps) {
  return (
    <div className="bg-brand-black min-h-screen text-brand-ivoire flex flex-col items-center justify-center pt-28 pb-20 px-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="relative inline-flex items-center justify-center p-4 bg-brand-charcoal rounded-full border border-brand-gold/20 shadow-xl">
          <Flame size={48} className="text-brand-braise animate-pulse" />
        </div>

        <div className="space-y-2">
          <span className="font-mono text-xs text-brand-gold font-bold tracking-widest block uppercase">
            Erreur 404
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-white">
            Oups, cette cuisson est manquée !
          </h1>
          <div className="w-12 h-[1px] bg-brand-gold mx-auto my-3" />
          <p className="text-sm text-gray-400 font-sans leading-relaxed">
            La page ou le plat que vous recherchez n'existe pas ou a été déplacé. Retournons à la cuisine principale pour trouver de succulentes grillades !
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <button
            onClick={() => onNavigate("/")}
            className="w-full py-3 bg-brand-gold hover:bg-brand-gold-light text-brand-black font-sans font-bold text-xs rounded-xl uppercase tracking-wider transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-md"
          >
            <Home size={14} />
            <span>Retourner à l'accueil</span>
          </button>
          
          <button
            onClick={() => onNavigate("/menu")}
            className="w-full py-3 bg-brand-charcoal hover:bg-brand-charcoal/80 text-brand-ivoire border border-brand-gold/15 font-sans font-bold text-xs rounded-xl uppercase tracking-wider transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <ArrowLeft size={14} />
            <span>Consulter la carte</span>
          </button>
        </div>
      </div>
    </div>
  );
}
