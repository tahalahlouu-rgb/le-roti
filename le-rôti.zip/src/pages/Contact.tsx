import React, { useState } from "react";
import { restaurantConfig } from "../data/restaurant";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  MessageSquare, 
  ShieldCheck, 
  Star, 
  Car, 
  Bus, 
  Navigation, 
  Plus, 
  X, 
  Filter,
  UserCheck
} from "lucide-react";

interface Review {
  id: string;
  name: string;
  rating: number;
  date: string;
  comment: string;
  dish: string;
  avatarColor: string;
}

const INITIAL_REVIEWS: Review[] = [
  {
    id: "rev-1",
    name: "Yasmine Berrada",
    rating: 5,
    date: "Il y a 3 jours",
    comment: "Le meilleur poulet rôti de Rabat, et de loin ! La marinade est exceptionnelle, la viande est super tendre et juteuse. Les frites maison sont croustillantes à souhait. Le service au food court de Ryad Square est rapide et agréable !",
    dish: "Demi Poulet Rôti",
    avatarColor: "bg-amber-500"
  },
  {
    id: "rev-2",
    name: "Omar El Fassi",
    rating: 5,
    date: "Il y a 1 semaine",
    comment: "La Seffa Mdfouna du lundi est une véritable tuerie ! Portion très généreuse, goût authentique comme à la maison. L'équipe du Rôtî est adorable et passionnée. Je recommande les yeux fermés.",
    dish: "Seffa Mdfouna",
    avatarColor: "bg-emerald-500"
  },
  {
    id: "rev-3",
    name: "Sophia Alami",
    rating: 5,
    date: "Il y a 2 semaines",
    comment: "Un régal absolu pour toute la famille. Les enfants adorent le gratin de poulet ultra crémeux et les jus d'orange pressés minute. Tout est super propre, ce qui est essentiel pour un restaurant. Bravo !",
    dish: "Gratin de Poulet",
    avatarColor: "bg-blue-500"
  },
  {
    id: "rev-4",
    name: "Tariq Bensouda",
    rating: 4,
    date: "Il y a 3 semaines",
    comment: "Le rituel du dimanche : poulet rôti entier à emporter. Toujours chaud et doré à point. Le jus de citron menthe pressé minute est excellent pour accompagner le repas.",
    dish: "Poulet Rôti Entier",
    avatarColor: "bg-purple-500"
  },
  {
    id: "rev-5",
    name: "Laila Mezouar",
    rating: 5,
    date: "Il y a 1 mois",
    comment: "Le couscous traditionnel du vendredi est tout simplement exceptionnel. Les sept légumes sont bien fondants et savoureux. Servi avec son petit bol de Lben frais, c'est le bonheur du vendredi midi à Rabat !",
    dish: "Couscous Sept Légumes",
    avatarColor: "bg-rose-500"
  }
];

export default function Contact() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "Qualité de service",
    message: ""
  });

  // Map / Transport tabs state
  const [activeRouteTab, setActiveRouteTab] = useState<"voiture" | "bus" | "pied">("voiture");

  // Reviews state
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [ratingFilter, setRatingFilter] = useState<number | "all">("all");
  
  // Write Review Modal state
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [newReview, setNewReview] = useState({
    name: "",
    rating: 5,
    comment: "",
    dish: "Poulet Rôti Classique"
  });
  const [hoveredStars, setHoveredStars] = useState<number | null>(null);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setFormSubmitted(true);
    }
  };

  const handleReset = () => {
    setFormData({ name: "", email: "", subject: "Qualité de service", message: "" });
    setFormSubmitted(false);
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReview.name.trim() && newReview.comment.trim()) {
      const colors = ["bg-amber-500", "bg-emerald-500", "bg-blue-500", "bg-purple-500", "bg-rose-500", "bg-teal-500"];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      
      const newlyAdded: Review = {
        id: `rev-${Date.now()}`,
        name: newReview.name,
        rating: newReview.rating,
        date: "À l'instant",
        comment: newReview.comment,
        dish: newReview.dish,
        avatarColor: randomColor
      };

      setReviews([newlyAdded, ...reviews]);
      setReviewSubmitted(true);
      setTimeout(() => {
        setIsReviewModalOpen(false);
        setReviewSubmitted(false);
        // Reset fields
        setNewReview({
          name: "",
          rating: 5,
          comment: "",
          dish: "Poulet Rôti Classique"
        });
      }, 1200);
    }
  };

  // Filter logic
  const filteredReviews = reviews.filter(rev => {
    if (ratingFilter === "all") return true;
    return rev.rating === ratingFilter;
  });

  // Calculate dynamic stats
  const totalReviewsCount = reviews.length;
  const averageRating = (reviews.reduce((acc, curr) => acc + curr.rating, 0) / totalReviewsCount).toFixed(1);

  // Helper count for rating stars
  const countStars = (starRating: number) => {
    return reviews.filter(r => r.rating === starRating).length;
  };

  return (
    <div className="bg-brand-black min-h-screen text-brand-ivoire pt-28 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page Heading */}
        <div className="text-center space-y-4 mb-12 animate-fade-in">
          <span className="font-serif text-brand-gold text-lg italic tracking-wider block">
            Nous Situer & Échanger
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-white">
            Contact & Accès
          </h1>
          <div className="w-20 h-[1.5px] bg-brand-gold mx-auto" />
          <p className="max-w-2xl mx-auto text-sm text-gray-400 font-sans leading-relaxed">
            Retrouvez-nous facilement au Food Court de Ryad Square Souissi ou partagez votre expérience avec nous.
          </p>
        </div>

        {/* Informative Warning Banner (Food court constraint compliance) */}
        <div className="max-w-4xl mx-auto mb-16 p-5 bg-brand-charcoal border border-brand-gold/30 rounded-2xl flex flex-col sm:flex-row items-center gap-4 shadow-xl">
          <div className="p-3 bg-brand-black rounded-full text-brand-gold shrink-0">
            <AlertTriangle size={24} className="animate-pulse text-brand-gold" />
          </div>
          <div className="space-y-1 font-sans text-center sm:text-left">
            <h4 className="font-serif text-lg font-bold text-white">
              Une Restauration en Libre-Accès (Food Court)
            </h4>
            <p className="text-xs text-gray-300 leading-relaxed">
              Le Rotî est installé dans le prestigieux Food Court de <strong>Ryad Square, Souissi, Rabat</strong>. À ce titre, le restaurant ne dispose pas de réservations privées de tables. Les places assises du Food Court sont en accès libre et gratuit pour tous nos clients !
            </p>
          </div>
        </div>

        {/* Split Grid layout - Main Contact Cards & Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          
          {/* Left column: Address, hours and visual cards */}
          <div className="lg:col-span-5 space-y-8">
            
            {/* Visual Location Info */}
            <div className="bg-brand-charcoal/45 border border-brand-gold/10 rounded-2xl p-6 space-y-6 shadow-lg transform hover:border-brand-gold/20 transition-all duration-300">
              <h3 className="font-serif text-2xl font-bold text-white">
                Notre Adresse
              </h3>
              
              <div className="space-y-4 font-sans text-sm text-gray-300">
                <div className="flex items-start space-x-3">
                  <MapPin size={20} className="text-brand-gold shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block">Le Rotî — Ryad Square</span>
                    <span className="text-xs text-gray-400">{restaurantConfig.location}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Phone size={18} className="text-brand-gold shrink-0" />
                  <div>
                    <span className="font-bold text-white block">Téléphone</span>
                    <span className="text-xs text-gray-400">{restaurantConfig.phone}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Mail size={18} className="text-brand-gold shrink-0" />
                  <div>
                    <span className="font-bold text-white block">Adresse Mail</span>
                    <span className="text-xs text-gray-400">contact@leroti.ma</span>
                  </div>
                </div>
              </div>

              {/* Action buttons to go to Maps */}
              <div className="pt-2">
                <a
                  href={restaurantConfig.mapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-brand-gold hover:bg-brand-gold-light text-brand-black text-xs font-bold font-sans rounded-xl tracking-wider uppercase flex items-center justify-center space-x-2 transition-all shadow-md active:scale-95"
                >
                  <MapPin size={14} />
                  <span>Ouvrir sur Google Maps</span>
                </a>
              </div>
            </div>

            {/* Hours card */}
            <div className="bg-brand-charcoal/45 border border-brand-gold/10 rounded-2xl p-6 space-y-4 shadow-lg font-sans transform hover:border-brand-gold/20 transition-all duration-300">
              <h3 className="font-serif text-2xl font-bold text-white">
                Heures de Service
              </h3>
              
              <div className="divide-y divide-brand-gold/5 text-sm space-y-3 pt-2">
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-400 font-medium">Lundi à Vendredi</span>
                  <span className="font-bold text-brand-gold-light">{restaurantConfig.hours.weekdays}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-400 font-medium">Samedi et Dimanche</span>
                  <span className="font-bold text-brand-gold-light">{restaurantConfig.hours.weekends}</span>
                </div>
              </div>

              <div className="p-3 bg-brand-black/60 rounded-xl border border-brand-gold/5 flex items-start space-x-2 text-xs text-gray-400 leading-relaxed">
                <Clock size={16} className="text-brand-gold shrink-0 mt-0.5" />
                <span>Notre cuisine prépare vos grillades chaudes en continu de l'ouverture à la fermeture du centre.</span>
              </div>
            </div>

            {/* Certifications Box */}
            <div className="p-4 bg-brand-roti/10 border border-brand-roti/30 rounded-xl flex items-center space-x-3 font-sans">
              <ShieldCheck size={28} className="text-brand-gold shrink-0" />
              <div>
                <span className="block font-bold text-white text-xs uppercase tracking-wide">
                  Qualité de Viande Certifiée
                </span>
                <span className="text-[11px] text-gray-400 leading-tight">
                  Toutes nos volailles sont fraîches, d'origine marocaine locale, et certifiées 100% Halal.
                </span>
              </div>
            </div>

          </div>

          {/* Right column: Interactive Suggestions Form */}
          <div className="lg:col-span-7 bg-brand-charcoal/30 border border-brand-gold/10 rounded-2xl p-6 sm:p-8 shadow-lg">
            <h3 className="font-serif text-2xl font-bold text-white mb-2">
              Nous Écrire / Vos Retours
            </h3>
            <p className="text-xs text-gray-400 font-sans mb-6">
              Votre avis compte beaucoup pour nous permettre de vous offrir le meilleur service à Rabat. Écrivez-nous directement en remplissant ce formulaire.
            </p>

            {formSubmitted ? (
              <div className="py-12 px-6 bg-brand-black/40 rounded-xl border border-brand-gold/15 text-center space-y-5">
                <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mx-auto text-brand-gold">
                  <CheckCircle2 size={32} />
                </div>
                <h4 className="font-serif text-2xl font-bold text-white">
                  Message Envoyé !
                </h4>
                <p className="text-sm text-gray-300 font-sans max-w-md mx-auto leading-relaxed">
                  Merci beaucoup pour votre message. Notre équipe à Rabat examine toutes vos remarques et vous répondra au plus vite par e-mail si nécessaire.
                </p>
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 bg-brand-gold hover:bg-brand-gold-light text-brand-black font-sans font-bold text-xs rounded-full uppercase cursor-pointer transition-all duration-300"
                >
                  Envoyer un autre message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 font-sans text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name input */}
                  <div className="space-y-1">
                    <label className="text-xs text-gray-400 font-medium uppercase tracking-wider block">
                      Votre nom entier <span className="text-brand-gold">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all"
                      placeholder="Ex: Taha Lahlou"
                    />
                  </div>

                  {/* Email input */}
                  <div className="space-y-1">
                    <label className="text-xs text-gray-400 font-medium uppercase tracking-wider block">
                      Votre adresse e-mail <span className="text-brand-gold">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all"
                      placeholder="Ex: taha@gmail.com"
                    />
                  </div>
                </div>

                {/* Subject Selector */}
                <div className="space-y-1">
                  <label className="text-xs text-gray-400 font-medium uppercase tracking-wider block">
                    Objet de votre message <span className="text-brand-gold">*</span>
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-3 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all cursor-pointer"
                  >
                    <option value="Qualité de service">Qualité de service au comptoir</option>
                    <option value="Qualité de cuisson">Qualité de cuisson de nos plats</option>
                    <option value="Suggestion de recette">Suggestion de nouvelle recette</option>
                    <option value="Collaboration">Demande de partenariat / Événement</option>
                    <option value="Autre">Autre sujet</option>
                  </select>
                </div>

                {/* Message input */}
                <div className="space-y-1">
                  <label className="text-xs text-gray-400 font-medium uppercase tracking-wider block">
                    Votre message <span className="text-brand-gold">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all resize-none"
                    placeholder="Dites-nous ce que vous avez aimé ou comment nous pouvons nous améliorer..."
                  />
                </div>

                {/* Submit button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-brand-gold hover:bg-brand-gold-light text-brand-black font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg flex items-center justify-center space-x-2 cursor-pointer text-xs active:scale-98"
                  >
                    <Send size={14} />
                    <span>Envoyer mon message</span>
                  </button>
                </div>
              </form>
            )}

            {/* Note regarding official channels */}
            <div className="mt-6 pt-5 border-t border-brand-gold/5 flex items-center space-x-2.5 text-xs text-gray-500 font-sans">
              <MessageSquare size={16} className="text-brand-gold shrink-0" />
              <span>Pour toute question urgente concernant une commande en cours de livraison, merci d'utiliser directement l'application Glovo.</span>
            </div>

          </div>

        </div>

        {/* 1. Interactive Map & Itinerary Section */}
        <div id="interactive-map-section" className="mb-24 space-y-8">
          <div className="space-y-2">
            <h2 className="font-serif text-3xl font-bold text-white flex items-center gap-3">
              <MapPin className="text-brand-gold" size={28} />
              Carte Interactive & Itinéraires
            </h2>
            <p className="text-sm text-gray-400 max-w-2xl font-sans">
              Déplacez, zoomez et explorez la carte en temps réel ou suivez nos guides pour nous rejoindre au centre Ryad Square.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* The Google Maps Interactive Frame */}
            <div className="lg:col-span-8 bg-brand-charcoal/20 border border-brand-gold/10 rounded-3xl overflow-hidden p-2 shadow-xl flex flex-col justify-between">
              <div className="relative w-full rounded-2xl overflow-hidden h-[450px] bg-brand-black">
                <iframe 
                  title="Ryad Square Mall Google Map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3308.204565780004!2d-6.84035!3d33.951478!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda76c8c9a6aa005%3A0xc3b8a34b2f29377!2sRyad%20Square!5e0!3m2!1sfr!2sma!4v1719293452293!5m2!1sfr!2sma" 
                  className="absolute inset-0 w-full h-full border-0 grayscale opacity-90 hover:grayscale-0 transition-all duration-700"
                  allowFullScreen
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <div className="px-4 py-3 flex flex-wrap items-center justify-between gap-4 font-sans text-xs text-gray-400">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-brand-gold animate-ping" />
                  <span>Ryad Square Mall, Souissi, Rabat (3ème niveau Food Court)</span>
                </div>
                <div className="flex gap-4">
                  <span>Coordonnées: 33.9515° N, 6.8378° W</span>
                </div>
              </div>
            </div>

            {/* The Interactive Directions Assistant */}
            <div className="lg:col-span-4 bg-brand-charcoal/40 border border-brand-gold/10 rounded-3xl p-6 flex flex-col justify-between shadow-xl">
              <div className="space-y-6">
                <div className="space-y-1">
                  <span className="font-serif text-brand-gold italic text-xs block">
                    Calculateur de trajet
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-white">
                    Comment Venir ?
                  </h3>
                  <p className="text-xs text-gray-400 font-sans">
                    Choisissez votre moyen de locomotion pour afficher l'itinéraire conseillé.
                  </p>
                </div>

                {/* Transportation tabs */}
                <div className="grid grid-cols-3 gap-2 p-1 bg-brand-black/40 rounded-xl border border-brand-gold/10">
                  <button
                    onClick={() => setActiveRouteTab("voiture")}
                    className={`py-2.5 rounded-lg flex flex-col items-center justify-center gap-1 transition-all text-xs font-sans font-bold cursor-pointer ${
                      activeRouteTab === "voiture" 
                        ? "bg-brand-gold text-brand-black shadow-md" 
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <Car size={16} />
                    <span>Voiture</span>
                  </button>

                  <button
                    onClick={() => setActiveRouteTab("bus")}
                    className={`py-2.5 rounded-lg flex flex-col items-center justify-center gap-1 transition-all text-xs font-sans font-bold cursor-pointer ${
                      activeRouteTab === "bus" 
                        ? "bg-brand-gold text-brand-black shadow-md" 
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <Bus size={16} />
                    <span>Bus</span>
                  </button>

                  <button
                    onClick={() => setActiveRouteTab("pied")}
                    className={`py-2.5 rounded-lg flex flex-col items-center justify-center gap-1 transition-all text-xs font-sans font-bold cursor-pointer ${
                      activeRouteTab === "pied" 
                        ? "bg-brand-gold text-brand-black shadow-md" 
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <Navigation size={16} />
                    <span>À pied</span>
                  </button>
                </div>

                {/* Instructions content based on tab selection */}
                <div className="font-sans text-xs leading-relaxed text-gray-300 min-h-[160px] bg-brand-black/20 p-4 rounded-xl border border-brand-gold/5 space-y-4">
                  {activeRouteTab === "voiture" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Depuis l'autoroute Casablanca-Rabat :</span>
                        <p className="text-gray-400">Prendre la sortie Souissi/Hay Riad, continuer sur l'Avenue Abderrahim Bouabid puis l'Avenue Mohammed VI. Le Ryad Square sera à votre droite.</p>
                      </div>
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Depuis le Centre-ville (Agdal / Hassan) :</span>
                        <p className="text-gray-400">Emprunter l'Avenue de l'Atlas ou l'Avenue Mohammed VI direction Souissi. Suivre les panneaux Ryad Square Mall. Le centre dispose d'un vaste parking souterrain gratuit de 2 niveaux.</p>
                      </div>
                    </div>
                  )}

                  {activeRouteTab === "bus" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Lignes de Bus directes :</span>
                        <p className="text-gray-400">Prendre les lignes de bus Alsa <strong>L04</strong> ou <strong>L12</strong>, descendre à l'arrêt de bus Ryad Square (situé juste en face du centre commercial).</p>
                      </div>
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Option Tramway + Petit Taxi :</span>
                        <p className="text-gray-400">Descendre au terminus de la ligne 1 à la station <strong>Ibn Sina (Agdal)</strong>. Prendre ensuite un petit taxi rouge direction Souissi / Ryad Square (compter environ 10 minutes de trajet pour un tarif d'environ 15 DH).</p>
                      </div>
                    </div>
                  )}

                  {activeRouteTab === "pied" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Accès piétons sécurisés :</span>
                        <p className="text-gray-400">Entrée principale des piétons au rez-de-chaussée de Ryad Square Souissi. Des ascenseurs et des escalators modernes vous mèneront directement au 3ème niveau (Food Court).</p>
                      </div>
                      <div className="space-y-1">
                        <span className="font-bold text-white block">Depuis les résidences avoisinantes :</span>
                        <p className="text-gray-400">Le mall est situé à l'intersection majeure de l'avenue de la Rocade Sud et de l'avenue Mohammed VI, facile et sécurisé à arpenter par les trottoirs pavés de Souissi.</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-brand-gold/5 flex items-center justify-between">
                <span className="text-[11px] text-gray-500 font-sans">Besoin d'aide ?</span>
                <a 
                  href={`https://maps.google.com/?q=Ryad+Square+Rabat`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-brand-gold hover:text-brand-gold-light text-xs font-sans font-bold flex items-center gap-1 transition-all"
                >
                  Calculer mon itinéraire exact
                  <Navigation size={12} className="rotate-45" />
                </a>
              </div>

            </div>

          </div>
        </div>

        {/* 2. Customer Reviews ("Les Avis de la Communauté") Section */}
        <div id="customer-reviews-section" className="space-y-10 border-t border-brand-gold/10 pt-16 font-sans">
          
          {/* Header of Reviews Section */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold text-white flex items-center gap-3">
                <Star className="text-brand-gold fill-brand-gold" size={28} />
                L'Avis de nos Clients
              </h2>
              <p className="text-sm text-gray-400 max-w-2xl font-sans">
                Découvrez les retours authentiques de nos clients à Rabat ou partagez le vôtre en direct.
              </p>
            </div>
            
            <button
              onClick={() => setIsReviewModalOpen(true)}
              className="px-6 py-3 bg-brand-gold hover:bg-brand-gold-light text-brand-black rounded-xl font-bold font-sans text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 cursor-pointer shrink-0 self-start md:self-auto"
            >
              <Plus size={16} />
              <span>Laisser un Avis</span>
            </button>
          </div>

          {/* Rating Summary Card & Filter bar */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-brand-charcoal/20 border border-brand-gold/10 rounded-3xl p-6 sm:p-8">
            
            {/* Left box: Overall Rating score */}
            <div className="md:col-span-4 text-center md:border-r md:border-brand-gold/10 py-4 space-y-3">
              <div className="text-6xl sm:text-7xl font-serif font-extrabold text-white">
                {averageRating}
              </div>
              <div className="flex justify-center gap-1.5 text-brand-gold">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star 
                    key={s} 
                    size={22} 
                    className={`${s <= Math.round(Number(averageRating)) ? "fill-brand-gold" : "text-gray-600"}`} 
                  />
                ))}
              </div>
              <p className="text-xs text-gray-400 uppercase tracking-widest font-bold">
                Moyenne sur {totalReviewsCount} avis clients
              </p>
            </div>

            {/* Middle box: Rating bars */}
            <div className="md:col-span-5 space-y-2 px-0 sm:px-4">
              {[5, 4, 3, 2, 1].map((stars) => {
                const count = countStars(stars);
                const pct = totalReviewsCount > 0 ? (count / totalReviewsCount) * 100 : 0;
                return (
                  <div key={stars} className="flex items-center gap-3 text-xs">
                    <span className="w-12 text-gray-400 font-bold text-right">{stars} Étoiles</span>
                    <div className="flex-1 h-2.5 bg-brand-black rounded-full overflow-hidden border border-brand-gold/5">
                      <div 
                        className="h-full bg-brand-gold rounded-full transition-all duration-1000" 
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="w-8 text-gray-400 text-left font-bold">{count}</span>
                  </div>
                );
              })}
            </div>

            {/* Right box: Real-time dynamic helper description */}
            <div className="md:col-span-3 text-center md:text-left p-4 bg-brand-gold/5 rounded-2xl border border-brand-gold/10 font-sans space-y-2">
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <UserCheck size={18} className="text-brand-gold" />
                <span className="font-bold text-white text-xs">Avis 100% Vérifiés</span>
              </div>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Toutes les évaluations proviennent de nos clients réels au food court ou via les commandes de livraison à Rabat.
              </p>
            </div>

          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 py-2 border-b border-brand-gold/5">
            <div className="flex items-center gap-2.5 text-xs font-sans text-gray-400">
              <Filter size={14} className="text-brand-gold" />
              <span>Filtrer par note :</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setRatingFilter("all")}
                className={`px-4 py-1.5 rounded-full text-xs font-sans font-bold transition-all cursor-pointer ${
                  ratingFilter === "all" 
                    ? "bg-brand-gold text-brand-black" 
                    : "bg-brand-charcoal/40 text-gray-400 hover:text-white hover:bg-brand-charcoal"
                }`}
              >
                Tous les avis ({reviews.length})
              </button>

              {[5, 4, 3].map((starVal) => {
                const count = countStars(starVal);
                return (
                  <button
                    key={starVal}
                    onClick={() => setRatingFilter(starVal)}
                    className={`px-4 py-1.5 rounded-full text-xs font-sans font-bold transition-all flex items-center gap-1 cursor-pointer ${
                      ratingFilter === starVal 
                        ? "bg-brand-gold text-brand-black" 
                        : "bg-brand-charcoal/40 text-gray-400 hover:text-white hover:bg-brand-charcoal"
                    }`}
                  >
                    <span>{starVal} Étoiles</span>
                    <Star size={10} className={ratingFilter === starVal ? "fill-brand-black" : "fill-gray-500"} />
                    <span>({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Grid list of reviews */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReviews.length === 0 ? (
              <div className="col-span-full py-16 text-center text-gray-400 font-sans space-y-3">
                <Star size={40} className="mx-auto text-gray-700" />
                <p>Aucun avis trouvé pour cette note.</p>
                <button 
                  onClick={() => setRatingFilter("all")}
                  className="text-brand-gold underline text-xs font-bold"
                >
                  Afficher tous les avis
                </button>
              </div>
            ) : (
              filteredReviews.map((rev) => (
                <div 
                  key={rev.id} 
                  className="bg-brand-charcoal/40 border border-brand-gold/10 rounded-2xl p-5 shadow-md flex flex-col justify-between space-y-4 hover:border-brand-gold/20 transform hover:-translate-y-1 transition-all duration-300 font-sans"
                >
                  <div className="space-y-3">
                    {/* Header: User Avatar & Name */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-full ${rev.avatarColor} text-brand-black font-extrabold flex items-center justify-center text-sm shadow-inner`}>
                          {rev.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h4 className="font-bold text-white text-sm leading-tight">{rev.name}</h4>
                          <span className="text-[10px] text-gray-500">{rev.date}</span>
                        </div>
                      </div>
                      
                      {/* Certified Purchase Badge */}
                      <span className="px-2 py-0.5 bg-brand-gold/10 border border-brand-gold/20 rounded-md text-[9px] text-brand-gold uppercase tracking-wider font-bold">
                        Vérifié
                      </span>
                    </div>

                    {/* Star Rating display */}
                    <div className="flex gap-0.5 text-brand-gold">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star 
                          key={s} 
                          size={13} 
                          className={`${s <= rev.rating ? "fill-brand-gold text-brand-gold" : "text-gray-700"}`} 
                        />
                      ))}
                    </div>

                    {/* Review text */}
                    <p className="text-xs text-gray-300 leading-relaxed italic">
                      "{rev.comment}"
                    </p>
                  </div>

                  {/* Footer: Dish ordered */}
                  <div className="pt-3 border-t border-brand-gold/5 flex items-center justify-between text-[11px]">
                    <span className="text-gray-500">Plat commandé :</span>
                    <span className="font-semibold text-brand-gold-light bg-brand-black/50 px-2 py-0.5 rounded-lg border border-brand-gold/5">
                      {rev.dish}
                    </span>
                  </div>

                </div>
              ))
            )}
          </div>

        </div>

      </div>

      {/* 3. Interactive Write Review Popup Modal */}
      {isReviewModalOpen && (
        <div className="fixed inset-0 bg-brand-black/85 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in font-sans">
          <div className="bg-brand-charcoal border border-brand-gold/30 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative transform scale-100 transition-all duration-300">
            
            {/* Close button */}
            <button
              onClick={() => setIsReviewModalOpen(false)}
              className="absolute top-4 right-4 p-2 bg-brand-black/50 text-gray-400 hover:text-white rounded-full border border-brand-gold/10 hover:border-brand-gold/30 transition-all duration-300 cursor-pointer"
            >
              <X size={16} />
            </button>

            {reviewSubmitted ? (
              <div className="p-10 text-center space-y-4">
                <div className="w-16 h-16 bg-brand-gold/15 rounded-full flex items-center justify-center mx-auto text-brand-gold border border-brand-gold/20 animate-bounce">
                  <CheckCircle2 size={32} />
                </div>
                <h3 className="font-serif text-2xl font-bold text-white">Merci pour votre Avis !</h3>
                <p className="text-sm text-gray-300 max-w-sm mx-auto">
                  Votre commentaire a été publié avec succès. Il a été ajouté en direct à la liste des avis clients de la communauté.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddReview} className="p-6 sm:p-8 space-y-5">
                <div className="space-y-1">
                  <span className="font-serif text-brand-gold italic text-xs block">Partager votre bonheur gourmand</span>
                  <h3 className="font-serif text-2xl font-bold text-white">Laissez un Avis en Direct</h3>
                  <p className="text-xs text-gray-400">
                    Aidez les autres clients à choisir et donnez-nous votre avis sincère sur Le Rôtî.
                  </p>
                </div>

                {/* Rating selection (Interactive glowing stars) */}
                <div className="space-y-1.5">
                  <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">
                    Votre Note Générale <span className="text-brand-gold">*</span>
                  </label>
                  <div className="flex gap-2 py-1">
                    {[1, 2, 3, 4, 5].map((starVal) => {
                      const isHighlighted = hoveredStars !== null ? starVal <= hoveredStars : starVal <= newReview.rating;
                      return (
                        <button
                          key={starVal}
                          type="button"
                          onMouseEnter={() => setHoveredStars(starVal)}
                          onMouseLeave={() => setHoveredStars(null)}
                          onClick={() => setNewReview({ ...newReview, rating: starVal })}
                          className="p-1 transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                        >
                          <Star 
                            size={28} 
                            className={`transition-colors duration-200 ${
                              isHighlighted 
                                ? "fill-brand-gold text-brand-gold filter drop-shadow-[0_0_8px_rgba(230,175,46,0.5)]" 
                                : "text-gray-600"
                            }`} 
                          />
                        </button>
                      );
                    })}
                  </div>
                  <span className="text-[10px] text-gray-500 block italic">
                    {newReview.rating === 5 && "Excellent — Un régal absolu !"}
                    {newReview.rating === 4 && "Très Bon — Très satisfait du goût et de l'accueil !"}
                    {newReview.rating === 3 && "Moyen — Correct, mais peut s'améliorer."}
                    {newReview.rating === 2 && "Décevant — Ne correspond pas aux attentes."}
                    {newReview.rating === 1 && "Médiocre — Mauvaise expérience."}
                  </span>
                </div>

                {/* Name input */}
                <div className="space-y-1">
                  <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">
                    Votre Nom & Prénom <span className="text-brand-gold">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newReview.name}
                    onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all text-sm"
                    placeholder="Ex: Yasmine Alaoui"
                  />
                </div>

                {/* Dish drop down */}
                <div className="space-y-1">
                  <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">
                    Quel plat avez-vous goûté ?
                  </label>
                  <select
                    value={newReview.dish}
                    onChange={(e) => setNewReview({ ...newReview, dish: e.target.value })}
                    className="w-full px-4 py-2.5 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all text-sm cursor-pointer"
                  >
                    <option value="Demi Poulet Rôti">Demi Poulet Rôti</option>
                    <option value="Poulet Rôti Entier">Poulet Rôti Entier</option>
                    <option value="Seffa Mdfouna">Seffa Mdfouna</option>
                    <option value="Gratin de Poulet">Gratin de Poulet</option>
                    <option value="Couscous Sept Légumes">Couscous Sept Légumes</option>
                    <option value="Rfissa Marocaine">Rfissa Marocaine</option>
                    <option value="Sandwich & Club">Sandwich & Club Garni</option>
                    <option value="Pâtes Farfalle Poulet">Pâtes Farfalle Poulet</option>
                    <option value="Salade César ou Marocaine">Salade César / Marocaine</option>
                    <option value="Dessert / Jus Frais">Dessert / Jus Frais pressé</option>
                  </select>
                </div>

                {/* Comment textarea */}
                <div className="space-y-1">
                  <label className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">
                    Votre Commentaire <span className="text-brand-gold">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={newReview.comment}
                    onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                    className="w-full px-4 py-2.5 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all resize-none text-sm"
                    placeholder="Racontez-nous votre expérience gourmande (qualité de cuisson, marinade, frites, sauce...)..."
                  />
                </div>

                {/* Submit button */}
                <div className="pt-2 flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsReviewModalOpen(false)}
                    className="flex-1 py-3 bg-brand-black/40 hover:bg-brand-black text-gray-400 hover:text-white rounded-xl font-bold uppercase tracking-wider text-xs transition-all border border-brand-gold/5 cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-brand-gold hover:bg-brand-gold-light text-brand-black rounded-xl font-bold uppercase tracking-wider text-xs transition-all shadow-md active:scale-95 cursor-pointer"
                  >
                    Publier l'avis
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
