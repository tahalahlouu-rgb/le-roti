import React, { useState, useMemo } from "react";
import { motion } from "motion/react";
import { categories, menuItems } from "../data/menu";
import { MenuItem } from "../types";
import { restaurantConfig } from "../data/restaurant";
import { 
  Flame, 
  UtensilsCrossed, 
  Sparkles, 
  Sandwich, 
  Soup, 
  Salad, 
  Cookie, 
  CupSoda, 
  Cake, 
  Beer, 
  Search, 
  SlidersHorizontal, 
  ShoppingBag, 
  X,
  Info
} from "lucide-react";

// Icon mapper for categories
const getCategoryIcon = (iconName: string) => {
  switch (iconName) {
    case "Flame": return <Flame size={18} />;
    case "UtensilsCrossed": return <UtensilsCrossed size={18} />;
    case "Sparkles": return <Sparkles size={18} />;
    case "Sandwich": return <Sandwich size={18} />;
    case "Soup": return <Soup size={18} />;
    case "Salad": return <Salad size={18} />;
    case "Cookie": return <Cookie size={18} />;
    case "CupSoda": return <CupSoda size={18} />;
    case "Cake": return <Cake size={18} />;
    case "Beer": return <Beer size={18} />;
    default: return <UtensilsCrossed size={18} />;
  }
};

export default function Menu() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedTag, setSelectedTag] = useState<string>("all");

  // Simplified premium tags/filters
  const tags = [
    { id: "all", label: "Tous les plats" },
    { id: "tradition", label: "Traditions Marocaines" },
    { id: "veggie", label: "Options Végétariennes" },
    { id: "under50", label: "Petits Prix (< 50 MAD)" },
  ];

  // Filter menu items based on selected category, tags, and search query
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      // 1. Category filter
      if (selectedCategory !== "all" && item.category !== selectedCategory) {
        return false;
      }

      // 2. Search Query filter
      if (searchQuery.trim() !== "") {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc) {
          return false;
        }
      }

      // 3. Tag filter selection
      if (selectedTag === "tradition" && item.category !== "marocain" && !item.name.toLowerCase().includes("marocaine") && !item.name.toLowerCase().includes("harira")) {
        return false;
      }
      if (selectedTag === "veggie") {
        const lowerName = item.name.toLowerCase();
        const lowerCategory = item.category;
        const isVeggie = 
          lowerName.includes("végétarienne") || 
          lowerName.includes("velouté") || 
          lowerCategory.includes("boissons") || 
          lowerCategory.includes("jus") || 
          lowerCategory.includes("desserts") || 
          lowerName.includes("salade marocaine") || 
          lowerName.includes("carotte") || 
          lowerName.includes("frites") || 
          lowerName.includes("pomme de terre") || 
          lowerName.includes("purée") || 
          lowerName.includes("aubergines") || 
          lowerName.includes("courgette") || 
          lowerName.includes("riz") || 
          lowerName.includes("légumes") || 
          lowerName.includes("vermicelles");
        
        const isMeat = 
          lowerCategory === "rotisserie" || 
          lowerCategory === "plats-modernes" || 
          lowerCategory === "sandwichs" || 
          lowerName.includes("poulet") || 
          lowerName.includes("thon") || 
          lowerName.includes("cordon bleu") || 
          lowerName.includes("rfissa") || 
          lowerName.includes("seffa");

        if (!isVeggie || isMeat) {
          return false;
        }
      }
      if (selectedTag === "under50" && item.price >= 50) {
        return false;
      }

      return true;
    });
  }, [selectedCategory, searchQuery, selectedTag]);

  return (
    <div className="bg-brand-black min-h-screen text-brand-ivoire pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center space-y-4 mb-12">
          <span className="font-serif text-brand-gold text-lg italic tracking-wider block">
            Délices & Saveurs
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-white">
            Notre Carte Officielle
          </h1>
          <div className="w-20 h-[1.5px] bg-brand-gold mx-auto" />
          <p className="max-w-2xl mx-auto text-sm text-gray-400 font-sans leading-relaxed">
            Consultez notre carte et passez votre commande directement sur Glovo pour une livraison rapide à Rabat. Tous nos plats sont cuisinés minute avec des ingrédients frais.
          </p>
        </div>

        {/* VISUAL CATEGORIES BLOCKS GRID */}
        <div className="mb-14">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-6 border-b border-brand-gold/10 pb-4">
            <h3 className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center space-x-2">
              <span className="w-1 h-6 bg-brand-gold rounded-full" />
              <span>Nos Univers Gastronomiques</span>
            </h3>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-brand-gold/60">
              Cuisine Généreuse & Qualité
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  const dishesSection = document.getElementById("dishes-list-anchor");
                  if (dishesSection) {
                    dishesSection.scrollIntoView({ behavior: "smooth", block: "start" });
                  }
                }}
                className={`relative h-28 rounded-2xl overflow-hidden border transition-all duration-500 cursor-pointer text-left group ${
                  selectedCategory === cat.id
                    ? "border-brand-gold shadow-[0_4px_25px_-5px_rgba(212,175,55,0.45)] ring-1 ring-brand-gold"
                    : "border-brand-gold/10 hover:border-brand-gold/45 hover:shadow-[0_4px_15px_-5px_rgba(212,175,55,0.15)]"
                }`}
              >
                {/* Background Image of the Category */}
                <div className="absolute inset-0 z-0">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 brightness-[0.35] group-hover:brightness-[0.45]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                </div>

                {/* Content */}
                <div className="relative z-10 h-full p-4 flex flex-col justify-between items-start">
                  <span className={`p-1.5 rounded-lg text-brand-gold bg-brand-black/60 backdrop-blur-sm border border-brand-gold/15 transition-all duration-300 group-hover:scale-105 group-hover:bg-brand-gold group-hover:text-brand-black group-hover:border-transparent ${
                    selectedCategory === cat.id ? "bg-brand-gold text-brand-black" : ""
                  }`}>
                    {getCategoryIcon(cat.icon)}
                  </span>
                  
                  <div className="space-y-0.5">
                    <h4 className="font-serif text-xs sm:text-sm font-extrabold text-white group-hover:text-brand-gold transition-colors leading-tight">
                      {cat.name}
                    </h4>
                    <p className="text-[9px] text-gray-400 font-sans line-clamp-1 leading-tight">
                      {menuItems.filter((item) => item.category === cat.id).length} spécialités
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Anchor point to scroll to */}
        <div id="dishes-list-anchor" className="scroll-mt-24" />

        {/* SEARCH AND QUICK FILTERS BAR */}
        <div className="bg-brand-charcoal/80 border border-brand-gold/15 rounded-2xl p-4 sm:p-6 mb-10 shadow-lg space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full md:max-w-md">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-500 pointer-events-none">
                <Search size={18} />
              </span>
              <input
                type="text"
                placeholder="Rechercher un plat, une boisson..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-brand-black border border-brand-gold/10 rounded-xl text-brand-ivoire font-sans text-sm focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-brand-gold"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            {/* Info Message */}
            <div className="flex items-center space-x-2 text-xs text-brand-gold-light italic">
              <Info size={14} className="shrink-0" />
              <span>Poulet 100% Halal. Service continu tous les jours.</span>
            </div>
          </div>

          {/* Quick Filter Tag Badges */}
          <div className="flex flex-wrap gap-2 pt-2 border-t border-brand-gold/5">
            {tags.map((tag) => (
              <button
                key={tag.id}
                onClick={() => setSelectedTag(tag.id)}
                className={`px-4 py-1.5 rounded-full font-sans text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  selectedTag === tag.id
                    ? "bg-brand-gold text-brand-black shadow-md font-bold"
                    : "bg-brand-black/50 hover:bg-brand-charcoal text-brand-ivoire border border-brand-gold/15"
                }`}
              >
                {tag.label}
              </button>
            ))}
          </div>
        </div>

        {/* MAIN LAYOUT: CATEGORIES & DISHES GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* A. CATEGORIES NAV (Sticky Sidebar on Desktop, horizontal on mobile) */}
          <div className="lg:col-span-3 lg:sticky lg:top-28 space-y-2">
            <h3 className="font-serif text-brand-gold text-xs font-bold tracking-widest uppercase mb-4 pl-2 hidden lg:block">
              Catégories de la Carte
            </h3>
            
            {/* Desktop list */}
            <div className="hidden lg:flex flex-col space-y-1">
              <button
                onClick={() => setSelectedCategory("all")}
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-xl font-sans text-sm font-medium transition-all text-left cursor-pointer ${
                  selectedCategory === "all"
                    ? "bg-brand-gold text-brand-black font-semibold shadow-md"
                    : "text-brand-ivoire hover:bg-brand-charcoal"
                }`}
              >
                <SlidersHorizontal size={16} />
                <span>Tous les produits ({menuItems.length})</span>
              </button>
              {categories.map((cat) => {
                const count = menuItems.filter((i) => i.category === cat.id).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center justify-between w-full px-4 py-3 rounded-xl font-sans text-sm font-medium transition-all text-left cursor-pointer ${
                      selectedCategory === cat.id
                        ? "bg-brand-gold text-brand-black font-semibold shadow-md"
                        : "text-brand-ivoire hover:bg-brand-charcoal/80"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className={selectedCategory === cat.id ? "text-brand-black" : "text-brand-gold"}>
                        {getCategoryIcon(cat.icon)}
                      </span>
                      <span>{cat.name}</span>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      selectedCategory === cat.id ? "bg-brand-charcoal text-brand-gold" : "bg-brand-black text-gray-500"
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Mobile horizontal slider */}
            <div className="lg:hidden flex items-center space-x-2 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-thin">
              <button
                onClick={() => setSelectedCategory("all")}
                className={`flex items-center space-x-1.5 shrink-0 px-4 py-2.5 rounded-full font-sans text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === "all"
                    ? "bg-brand-gold text-brand-black font-bold shadow"
                    : "bg-brand-charcoal text-brand-ivoire border border-brand-gold/10"
                }`}
              >
                <SlidersHorizontal size={14} />
                <span>Tous ({menuItems.length})</span>
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center space-x-1.5 shrink-0 px-4 py-2.5 rounded-full font-sans text-xs font-semibold transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? "bg-brand-gold text-brand-black font-bold shadow"
                      : "bg-brand-charcoal text-brand-ivoire border border-brand-gold/10"
                  }`}
                >
                  <span className={selectedCategory === cat.id ? "text-brand-black" : "text-brand-gold-light"}>
                    {getCategoryIcon(cat.icon)}
                  </span>
                  <span>{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* B. DISHES GRID */}
          <div className="lg:col-span-9 space-y-8">
            
            {/* Show Category Description */}
            {selectedCategory !== "all" && (
              <div className="bg-brand-charcoal/30 border border-brand-gold/10 rounded-xl p-5 mb-2 font-sans">
                <h4 className="font-serif text-xl font-bold text-brand-gold-light mb-1">
                  {categories.find((c) => c.id === selectedCategory)?.name}
                </h4>
                <p className="text-xs text-gray-400 leading-relaxed">
                  {categories.find((c) => c.id === selectedCategory)?.description}
                </p>
              </div>
            )}

            {/* Dishes list */}
            {filteredItems.length === 0 ? (
              <div className="text-center py-20 bg-brand-charcoal/20 rounded-2xl border border-brand-gold/10 space-y-4">
                <SlidersHorizontal size={40} className="text-brand-gold/30 mx-auto" />
                <p className="font-serif text-lg text-brand-gold-light">Aucun plat ne correspond à vos critères</p>
                <p className="text-xs text-gray-400 font-sans">Essayez de réinitialiser vos filtres ou d'élargir votre recherche.</p>
                <button
                  onClick={() => {
                    setSelectedCategory("all");
                    setSelectedTag("all");
                    setSearchQuery("");
                  }}
                  className="px-5 py-2 bg-brand-gold text-brand-black font-sans font-bold text-xs rounded-full uppercase cursor-pointer"
                >
                  Réinitialiser la recherche
                </button>
              </div>
            ) : (
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
                initial="hidden"
                animate="show"
                variants={{
                  hidden: { opacity: 0 },
                  show: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.05
                    }
                  }
                }}
              >
                {filteredItems.map((item) => (
                  <motion.div
                    key={item.id}
                    variants={{
                      hidden: { opacity: 0, y: 15 },
                      show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
                    }}
                    className="flex flex-col h-full bg-brand-charcoal/30 border border-brand-gold/10 hover:border-brand-gold/40 hover:shadow-[0_12px_45px_-15px_rgba(212,175,55,0.18)] rounded-2xl p-5 transition-all duration-500 group"
                  >
                    {item.image ? (
                      /* Card with Image */
                      <>
                        <a 
                          href={restaurantConfig.orderUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative h-48 w-full overflow-hidden rounded-xl mb-4 bg-brand-black/40 border border-brand-gold/10 shrink-0 block"
                        >
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                            referrerPolicy="no-referrer"
                          />
                        </a>

                        {/* Content Area */}
                        <div className="flex flex-col flex-grow justify-between">
                          <div>
                            <div className="flex justify-between items-start gap-4 mb-2">
                              <h3 className="font-serif text-lg font-bold text-white group-hover:text-brand-gold transition-colors leading-tight">
                                <a 
                                  href={restaurantConfig.orderUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="hover:underline"
                                >
                                  {item.name}
                                </a>
                              </h3>
                              <span className="font-sans font-extrabold text-brand-gold shrink-0 text-sm sm:text-base">
                                {item.price.toFixed(2)} MAD
                              </span>
                            </div>
                            <p className="text-xs text-brand-ivoire/70 font-sans leading-relaxed mt-2 line-clamp-3">
                              {item.description}
                            </p>
                          </div>

                          <div className="mt-6 pt-4 border-t border-brand-ivoire/10 flex items-center justify-between">
                            <span className="font-sans text-[10px] text-gray-500 uppercase tracking-widest font-semibold">
                              {categories.find((c) => c.id === item.category)?.name}
                            </span>
                            <a
                              href={restaurantConfig.orderUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center space-x-1.5 px-4 py-2.5 bg-brand-gold hover:bg-brand-gold-light text-brand-black rounded-xl font-sans text-[11px] uppercase tracking-wider font-extrabold transition-all duration-300 shadow-md hover:scale-105"
                            >
                              <ShoppingBag size={12} />
                              <span>Commander sur Glovo</span>
                            </a>
                          </div>
                        </div>
                      </>
                    ) : (
                      /* Premium Text-Only Card (No Image Container, No empty boxes) */
                      <div className="flex flex-col flex-grow justify-between h-full">
                        <div>
                          {/* Elegant Header for Text Card */}
                          <div className="flex justify-between items-center mb-4 border-b border-brand-gold/10 pb-2">
                            <span className="font-mono text-[8px] uppercase tracking-[0.25em] text-brand-gold/50">Sélection Gourmet</span>
                            <span className="font-serif text-[10px] italic text-brand-gold/40">Le Rotî</span>
                          </div>

                          <div className="flex justify-between items-start gap-4 mb-3">
                            <h3 className="font-serif text-lg font-bold text-white group-hover:text-brand-gold transition-colors leading-tight">
                              <a 
                                href={restaurantConfig.orderUrl} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="hover:underline"
                              >
                                {item.name}
                              </a>
                            </h3>
                            <span className="font-sans font-extrabold text-brand-gold shrink-0 text-sm sm:text-base">
                              {item.price.toFixed(2)} MAD
                            </span>
                          </div>
                          
                          <p className="text-xs text-brand-ivoire/70 font-sans leading-relaxed mt-2 line-clamp-4">
                            {item.description}
                          </p>
                        </div>

                        <div className="mt-8 pt-4 border-t border-brand-ivoire/10 flex items-center justify-between">
                          <span className="font-sans text-[10px] text-gray-500 uppercase tracking-widest font-semibold">
                            {categories.find((c) => c.id === item.category)?.name}
                          </span>
                          <a
                            href={restaurantConfig.orderUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center space-x-1.5 px-4 py-2.5 bg-brand-gold hover:bg-brand-gold-light text-brand-black rounded-xl font-sans text-[11px] uppercase tracking-wider font-extrabold transition-all duration-300 shadow-md hover:scale-105"
                          >
                            <ShoppingBag size={12} />
                            <span>Commander sur Glovo</span>
                          </a>
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </motion.div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
