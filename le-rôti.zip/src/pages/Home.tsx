import React from "react";
import { motion, useScroll, useTransform } from "motion/react";
import Logo from "../components/Logo";
import { restaurantConfig } from "../data/restaurant";
import { menuItems } from "../data/menu";
import { ArrowRight, Flame, Shield, Award, ChevronRight, Instagram, MapPin, ShoppingBag } from "lucide-react";

interface HomeProps {
  onNavigate: (route: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  // Use scroll coordinates to implement high-end lightweight parallax effects
  const { scrollY } = useScroll();
  const imageParallaxY = useTransform(scrollY, [0, 600], [0, -35]);
  const imageScale = useTransform(scrollY, [0, 600], [1, 1.04]);

  // Extract a few featured menu items that have real photos
  const featuredItems = menuItems.filter((item) => item.image).slice(0, 3);

  const keyQualities = [
    {
      icon: <Flame size={24} className="text-brand-gold" />,
      title: "Rôtisserie Traditionnelle",
      description: "Une cuisson parfaitement maîtrisée pour des viandes juteuses à cœur et une peau dorée."
    },
    {
      icon: <Award size={24} className="text-brand-gold" />,
      title: "Recettes Authentiques",
      description: "Des assaisonnements équilibrés et des ingrédients soigneusement sélectionnés."
    },
    {
      icon: <Shield size={24} className="text-brand-gold" />,
      title: "Qualité Certifiée Halal",
      description: "Toutes nos viandes sont fraîches et issues d'approvisionnements certifiés halal."
    }
  ];

  const daysSpecials = [
    { day: "Lundi", dish: "Seffa Mdfouna", price: "69 MAD", desc: "Vermicelles vapeur fondantes garnies de poulet effiloché savoureusement épicé." },
    { day: "Mercredi", dish: "Rfissa au Poulet", price: "69 MAD", desc: "Plat traditionnel réconfortant à base de msemmen émincé et de lentilles mijotées." },
    { day: "Vendredi", dish: "Couscous Sept Légumineuses", price: "69 MAD", desc: "Le couscous traditionnel aux légumes frais de saison, servi avec son verre de Lben." }
  ];

  return (
    <div className="bg-brand-black min-h-screen text-brand-ivoire overflow-x-hidden">
      
      {/* 1. HERO SECTION - PREMIUM CINEMATIC LAYOUT */}
      <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 lg:py-0 bg-[#090909] overflow-hidden">
        
        {/* Animated appetizing roasted chicken background layer */}
        <div className="absolute inset-0 z-0 select-none overflow-hidden">
          
          {/* Flame layer behind the chicken (fireplace depth) */}
          <div className="absolute inset-x-0 bottom-0 h-96 pointer-events-none z-0 overflow-hidden opacity-55">
            {/* Flame Shape 1 */}
            <div className="absolute bottom-[-20px] right-[10%] lg:right-[15%] w-56 h-72 bg-gradient-to-t from-brand-braise via-brand-gold/40 to-transparent rounded-full filter blur-3xl animate-roti-flame-1 origin-bottom" />
            {/* Flame Shape 2 */}
            <div className="absolute bottom-[-10px] right-[25%] lg:right-[30%] w-72 h-80 bg-gradient-to-t from-brand-roti via-brand-braise/50 to-transparent rounded-full filter blur-[40px] animate-roti-flame-2 origin-bottom" />
            {/* Flame Shape 3 */}
            <div className="absolute bottom-[-30px] right-[5%] lg:right-[5%] w-48 h-60 bg-gradient-to-t from-brand-braise via-brand-gold/30 to-transparent rounded-full filter blur-2xl animate-roti-flame-3 origin-bottom" />
          </div>

          {/* Real Photo container with slow breath and movement */}
          <div className="absolute inset-0 w-full h-full z-10 animate-roti-breath scale-[1.05]">
            <img
              src="/src/assets/images/hero_rotisserie_1783705241916.jpg"
              alt="Le Rotî Poulet Rôti Entier"
              className="w-full h-full object-cover object-center lg:object-[right_center] brightness-[0.6] contrast-[1.1] select-none pointer-events-none"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // High-quality professional fallback just in case
                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1598515214211-89d3e73ae83b?auto=format&fit=crop&q=80&w=1200";
              }}
            />

            {/* Warm reflections passing over the skin of the chicken */}
            <div className="absolute inset-0 pointer-events-none mix-blend-color-dodge opacity-50 z-20 overflow-hidden">
              <div 
                className="w-[180%] h-[180%] absolute top-[-40%] left-[-40%] bg-gradient-to-r from-transparent via-brand-gold-light/25 to-transparent animate-roti-shimmer"
                style={{
                  background: "linear-gradient(115deg, transparent 25%, rgba(217, 191, 122, 0.25) 45%, rgba(251, 248, 241, 0.45) 50%, rgba(200, 100, 40, 0.35) 55%, transparent 75%)"
                }}
              />
            </div>
          </div>

          {/* Light smoke rising from the chicken area */}
          <div className="absolute inset-y-0 right-0 w-full lg:w-1/2 pointer-events-none z-25 overflow-hidden">
            <div className="absolute bottom-[35%] right-[15%] lg:right-[25%] w-48 h-48 bg-gradient-to-tr from-white/6 via-transparent to-transparent rounded-full filter blur-xl opacity-0 animate-roti-smoke-1" />
            <div className="absolute bottom-[40%] right-[25%] lg:right-[35%] w-56 h-56 bg-gradient-to-tr from-brand-ivoire/5 via-transparent to-transparent rounded-full filter blur-2xl opacity-0 animate-roti-smoke-2" />
            <div className="absolute bottom-[30%] right-[8%] lg:right-[15%] w-36 h-36 bg-gradient-to-tr from-white/5 via-transparent to-transparent rounded-full filter blur-xl opacity-0 animate-roti-smoke-3" />
          </div>

          {/* Golden juice drips falling under the chicken */}
          <div className="absolute bottom-[15%] right-[5%] lg:right-[20%] w-[450px] h-48 pointer-events-none z-25 overflow-hidden">
            <div className="absolute top-0 left-[35%] w-[4px] h-[4px] bg-brand-gold-light rounded-full shadow-[0_0_6px_#B79A55] opacity-0 animate-roti-drip-1" />
            <div className="absolute top-[8px] left-[52%] w-[3px] h-[3px] bg-brand-ivoire rounded-full shadow-[0_0_6px_#B79A55] opacity-0 animate-roti-drip-2" />
            <div className="absolute top-[-5px] left-[68%] w-[4.5px] h-[4.5px] bg-brand-gold rounded-full shadow-[0_0_6px_#C86428] opacity-0 animate-roti-drip-3" />
          </div>

          {/* Animated embers rising across the screen */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-25">
            {Array.from({ length: 20 }).map((_, i) => {
              const delay = i * 0.3;
              const left = `${10 + (i * 7.5) % 80}%`;
              const size = `${2 + (i % 3)}px`;
              const duration = `${5.2 + (i % 3)}s`;
              const drift = `${-45 + (i * 11) % 90}px`;
              return (
                <div
                  key={`ember-${i}`}
                  className="absolute bg-brand-braise rounded-full opacity-0"
                  style={{
                    left,
                    bottom: "5px",
                    width: size,
                    height: size,
                    boxShadow: "0 0 5px #C86428, 0 0 9px #B79A55",
                    animation: `roti-ember-particles ${duration} linear infinite ${delay}s`,
                    "--drift": drift,
                  } as React.CSSProperties}
                />
              );
            })}
          </div>

          {/* Dynamic dark gradient overlay for maximum readability of text */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/85 to-black/35 lg:from-black/95 lg:via-black/75 lg:to-black/30 z-20 pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_50%,_transparent_25%,_rgba(0,0,0,0.85)_85%)] z-20 pointer-events-none" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-30">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Cinematic Text Reveal Content */}
            <div className="lg:col-span-7 space-y-8 text-center lg:text-left flex flex-col items-center lg:items-start">
              <motion.div
                initial={{ opacity: 0, y: -15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="mb-2"
              >
                <Logo variant="ivory-badge" showSlogan={false} className="shadow-2xl scale-105 tracking-[0.25em]" />
              </motion.div>

              <div className="space-y-4 max-w-xl">
                <motion.h1
                  initial={{ opacity: 0, y: 25 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
                  className="font-serif text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-white leading-[1.1]"
                >
                  Bien plus que du poulet.
                </motion.h1>

                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
                  className="text-base sm:text-lg text-brand-ivoire/95 font-light font-sans leading-relaxed"
                >
                  Poulets rôtis, plats modernes, recettes marocaines et saveurs généreuses au cœur de Ryad Square.
                </motion.p>
              </div>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
                className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
              >
                <button
                  onClick={() => onNavigate("/menu")}
                  className="w-full sm:w-auto px-8 py-4 bg-brand-gold hover:bg-brand-gold-light text-brand-black font-sans font-extrabold text-xs uppercase tracking-widest rounded-full shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer flex items-center justify-center space-x-2"
                >
                  <span>Découvrir la carte</span>
                  <ChevronRight size={14} />
                </button>
                <a
                  href={restaurantConfig.orderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-8 py-4 bg-brand-charcoal/90 hover:bg-brand-black text-brand-ivoire border border-brand-ivoire/20 hover:border-brand-gold font-sans font-extrabold text-xs uppercase tracking-widest rounded-full shadow-lg transition-all duration-300 hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <ShoppingBag size={14} className="text-brand-gold" />
                  <span>Commander sur Glovo</span>
                </a>
              </motion.div>
            </div>

            {/* Empty right column so that the background roasted chicken visual is perfectly visible and unobstructed on desktop */}
            <div className="lg:col-span-5 h-20 lg:h-auto pointer-events-none" />

          </div>
        </div>

        {/* Elegant Animated Floating Scroll Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-1 text-brand-gold/50 text-[9px] font-sans tracking-[0.3em] uppercase z-20 pointer-events-none">
          <span className="animate-bounce">↓</span>
        </div>
      </section>

      {/* 2. THE BRAND STORY / CRAFT */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-brand-gold/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          <div className="lg:col-span-5 space-y-6">
            <span className="font-serif text-brand-gold text-lg tracking-wider block font-semibold italic">
              L'Art du Goût et de la Qualité
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
              Bien plus que du poulet, une passion culinaire.
            </h2>
            <div className="w-16 h-[2px] bg-brand-gold" />
            <p className="text-gray-400 font-sans text-sm sm:text-base leading-relaxed">
              Chez Le Rotî, chaque détail compte. De la sélection rigoureuse de nos viandes fraîches aux mélanges d'herbes aromatiques qui relèvent nos spécialités, nous veillons à vous offrir une expérience gustative de qualité au quotidien.
            </p>
            <p className="text-gray-400 font-sans text-sm leading-relaxed">
              Nos spécialités sont préparées chaque jour avec le plus grand soin par notre équipe. Un équilibre parfait entre moelleux à l'intérieur et croustillant doré à l'extérieur, idéal à partager en famille ou entre amis.
            </p>
            <div className="pt-4">
              <button
                onClick={() => onNavigate("/menu")}
                className="inline-flex items-center space-x-2 font-sans font-bold text-brand-gold hover:text-brand-gold-light text-sm tracking-wide cursor-pointer group"
              >
                <span>Parcourir notre carte complète</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Genuine Official Food Images in the Grid */}
          <div className="lg:col-span-7 grid grid-cols-12 gap-4">
            <div className="col-span-8 rounded-2xl overflow-hidden shadow-2xl border border-brand-gold/10 transform hover:scale-[1.01] transition-transform duration-500">
              <img
                src="/src/assets/images/moroccan_rfissa_1783705276130.jpg"
                alt="Rfissa Traditionnelle au Poulet"
                className="w-full h-80 object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="col-span-4 rounded-2xl overflow-hidden shadow-2xl border border-brand-gold/10 self-end transform translate-y-6 hover:scale-[1.01] transition-transform duration-500">
              <img
                src="https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600"
                alt="Seffa Mdfouna"
                className="w-full h-48 object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 3. KEY QUALITIES (Three pillars) */}
      <section className="bg-brand-charcoal/50 border-y border-brand-gold/10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {keyQualities.map((item, index) => (
              <div
                key={index}
                className="flex flex-col items-center md:items-start text-center md:text-left space-y-4 p-6 rounded-xl border border-brand-gold/5 bg-brand-charcoal/30 hover:border-brand-gold/15 hover:bg-brand-charcoal/60 transition-all duration-300"
              >
                <div className="p-3 rounded-full bg-brand-black border border-brand-gold/10">
                  {item.icon}
                </div>
                <h3 className="font-serif text-xl font-semibold text-brand-gold-light">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-400 font-sans leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. SIGNATURES / HIGHLIGHTS SECTION */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <span className="font-serif text-brand-gold text-lg italic tracking-wider">
            Notre Sélection
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white">
            Nos Créations Incontournables
          </h2>
          <div className="w-24 h-[1px] bg-brand-gold mx-auto mt-2" />
          <p className="max-w-xl mx-auto text-sm text-gray-400 font-sans">
            Une sélection de nos plats les plus appréciés, préparés minute à Rabat Ryad Square.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredItems.map((item) => (
            <div
              key={item.id}
              className="flex flex-col bg-brand-charcoal/30 border border-brand-gold/10 rounded-xl overflow-hidden hover:border-brand-gold/35 transition-all duration-300 group shadow-lg"
            >
              <a 
                href={restaurantConfig.orderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="relative h-64 overflow-hidden bg-brand-black flex items-center justify-center block"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
              </a>
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex justify-between items-baseline mb-2">
                    <h3 className="font-serif text-xl font-bold text-white group-hover:text-brand-gold transition-colors leading-tight">
                      <a 
                        href={restaurantConfig.orderUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:underline"
                      >
                        {item.name}
                      </a>
                    </h3>
                    <span className="font-sans font-extrabold text-brand-gold ml-2 shrink-0">
                      {item.price.toFixed(2)} MAD
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 font-sans leading-relaxed">
                    {item.description}
                  </p>
                </div>
                <a
                  href={restaurantConfig.orderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 rounded-xl bg-brand-gold text-brand-black text-center font-sans text-xs font-extrabold uppercase tracking-wider hover:bg-brand-gold-light transition-all duration-300"
                >
                  Commander sur Glovo
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. SPECIFIC DAYS SPECIALS (Plats Marocains Hebdo) */}
      <section className="bg-brand-charcoal/40 border-t border-brand-gold/10 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-4 space-y-4">
              <span className="font-serif text-brand-gold text-lg italic tracking-wider block">
                Traditions Hebdomadaires
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
                Les Rendez-vous Marocains
              </h2>
              <p className="text-sm text-gray-400 font-sans leading-relaxed">
                Parce que nous sommes attachés aux saveurs authentiques de notre terroir, nous vous proposons trois rendez-vous incontournables dans la semaine. Des recettes familiales préparées chaque jour avec patience.
              </p>
              <div className="p-3 bg-brand-gold/5 border border-brand-gold/20 text-xs text-brand-gold-light rounded-lg leading-relaxed font-sans">
                <strong>Important :</strong> Ces plats sont servis exclusivement les jours indiqués, en quantités limitées pour garantir une fraîcheur absolue.
              </div>
            </div>

            <div className="lg:col-span-8 space-y-4">
              {daysSpecials.map((special, index) => (
                <div
                  key={index}
                  className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-6 rounded-xl border border-brand-gold/10 bg-brand-black/40 hover:border-brand-gold/30 transition-all duration-300"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-3">
                      <span className="font-sans font-bold text-xs uppercase px-2.5 py-1 bg-brand-gold text-brand-black rounded">
                        {special.day}
                      </span>
                      <h4 className="font-serif text-lg font-bold text-white">
                        {special.dish}
                      </h4>
                    </div>
                    <p className="text-xs text-gray-400 font-sans leading-relaxed max-w-md mt-1">
                      {special.desc}
                    </p>
                  </div>
                  <div className="mt-3 sm:mt-0 font-sans font-extrabold text-brand-gold text-lg shrink-0">
                    {special.price}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. INSTAGRAM SECTION */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-brand-gold/10">
        <div className="text-center space-y-4 mb-16">
          <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-white">
            Suivez notre aventure
          </h2>
          <p className="text-sm text-gray-400 font-sans max-w-md mx-auto">
            Rejoignez notre communauté sur Instagram <a href={restaurantConfig.instagram} target="_blank" rel="noopener noreferrer" className="text-brand-gold font-bold hover:underline">@leroti_ma</a> pour suivre nos coulisses et nos offres.
          </p>
        </div>

        {/* Visual grid representing premium instagram feel using real webp assets */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { tag: "#Générosité", text: "Poulet rôti doré et fondant prêt à servir", img: "/src/assets/images/hero_rotisserie_1783705241916.jpg" },
            { tag: "#Tradition", text: "Rfissa marocaine généreuse et parfumée", img: "/src/assets/images/moroccan_rfissa_1783705276130.jpg" },
            { tag: "#Partage", text: "Couscous savoureux du vendredi midi", img: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600" },
            { tag: "#Douceur", text: "Gâteau au fromage citronné préparé maison", img: "https://images.unsplash.com/photo-1524351199679-46cddf530c04?auto=format&fit=crop&q=80&w=600" }
          ].map((post, idx) => (
            <a
              key={idx}
              href={restaurantConfig.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="relative aspect-square group overflow-hidden bg-brand-charcoal/80 rounded-xl border border-brand-gold/5 flex flex-col justify-end p-6"
            >
              <img
                src={post.img}
                alt={post.tag}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-[0.4] group-hover:brightness-[0.45]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-brand-black/30 to-transparent" />
              <div className="relative z-10 space-y-1">
                <span className="text-brand-gold font-mono text-[10px] font-bold tracking-wider block uppercase">
                  {post.tag}
                </span>
                <p className="text-xs text-brand-ivoire/90 font-sans leading-relaxed group-hover:text-white transition-colors">
                  {post.text}
                </p>
              </div>
            </a>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href={restaurantConfig.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-full border border-brand-gold/20 hover:border-brand-gold hover:bg-brand-gold hover:text-brand-black font-sans text-xs font-bold transition-all duration-300"
          >
            <span>Voir notre profil Instagram</span>
          </a>
        </div>
      </section>

      {/* 7. CTA / ACCÈS QUICK LINK */}
      <section className="bg-gradient-to-r from-brand-charcoal to-brand-brown-black py-20 border-t border-brand-gold/10">
        <div className="max-w-4xl mx-auto px-4 text-center space-y-6">
          <MapPin size={32} className="text-brand-gold mx-auto animate-bounce" />
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
            Pas besoin de réserver, venez nous voir !
          </h2>
          <p className="text-sm text-gray-300 font-sans max-w-xl mx-auto leading-relaxed">
            Situé au cœur du Food Court de <strong>Ryad Square à Rabat</strong>, Le Rotî vous accueille sans réservation de table. Venez profiter de l'ambiance chaleureuse du Food Court et savourez nos spécialités chaudes sur place ou à emporter.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4">
            <button
              onClick={() => onNavigate("/contact")}
              className="w-full sm:w-auto px-7 py-3.5 bg-brand-gold hover:bg-brand-gold-light text-brand-black font-sans font-bold text-xs rounded-full uppercase tracking-wider transition-all duration-300 cursor-pointer"
            >
              Voir l'itinéraire & les accès
            </button>
            <a
              href={restaurantConfig.orderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-7 py-3.5 bg-brand-black/60 border border-brand-gold/30 hover:border-brand-gold text-brand-ivoire font-sans font-bold text-xs rounded-full uppercase tracking-wider transition-all duration-300 text-center"
            >
              Commander sur Glovo
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
